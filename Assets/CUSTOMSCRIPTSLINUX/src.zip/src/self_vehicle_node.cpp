#include "self_vehicle.hpp"
#include <rclcpp/qos.hpp>
#include <algorithm>
#include <cmath>
#include <deque>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>
#include <cv_bridge/cv_bridge.h>
#include <opencv2/opencv.hpp>
#include <opencv2/imgproc.hpp>

namespace self_vehicle
{

static constexpr double SYNC_MAX_TIME_DIFF = 2.0;
static constexpr double EPS = 1e-6;
static constexpr size_t MAX_HISTORY = 200;

template<typename T>
static bool getClosest(
    const std::deque<T>& queue,
    const rclcpp::Time& stamp,
    T& out,
    double max_diff,
    bool& exact)
{
    if (queue.empty()) return false;
    T best = queue.front();
    double best_diff = std::abs((rclcpp::Time(best->header.stamp) - stamp).seconds());
    for (const auto& item : queue) {
        double diff = std::abs((rclcpp::Time(item->header.stamp) - stamp).seconds());
        if (diff < best_diff) {
            best_diff = diff;
            best = item;
        }
    }
    exact = (best_diff <= max_diff);
    out = best;
    return true;
}

SelfVehicleNode::SelfVehicleNode() : Node("self_vehicle")
{
    // 参数声明（自车外参，用于将点云变换到自车相机坐标系）
    this->declare_parameter("self_transform_x", -0.1);
    this->declare_parameter("self_transform_y", -0.05);
    this->declare_parameter("self_transform_z", 0.0175);
    this->declare_parameter("self_roll_offset", -90.0);
    this->declare_parameter("self_pitch_offset", 0.0);
    this->declare_parameter("self_yaw_offset", 0.0);

    // 他车外参（从 /another_extrinsic 接收，但保留参数作为备用）
    this->declare_parameter("other_transform_x", -0.1);
    this->declare_parameter("other_transform_y", -0.05);
    this->declare_parameter("other_transform_z", 0.0175);
    this->declare_parameter("other_roll_offset", -90.0);
    this->declare_parameter("other_pitch_offset", 0.0);
    this->declare_parameter("other_yaw_offset", 0.0);

    // 盲区填补参数
    this->declare_parameter("patch_cols", 15);
    this->declare_parameter("patch_rows", 15);
    this->declare_parameter("deg_thresh", 5.0);
    this->declare_parameter("blind_left_top_x", 500.0);
    this->declare_parameter("blind_left_top_y", 400.0);
    this->declare_parameter("blind_right_bottom_x", 600.0);
    this->declare_parameter("blind_right_bottom_y", 500.0);

    // 读取参数
    double tx_s = this->get_parameter("self_transform_x").as_double();
    double ty_s = this->get_parameter("self_transform_y").as_double();
    double tz_s = this->get_parameter("self_transform_z").as_double();
    double roll_s = this->get_parameter("self_roll_offset").as_double() * M_PI / 180.0;
    double pitch_s = this->get_parameter("self_pitch_offset").as_double() * M_PI / 180.0;
    double yaw_s = this->get_parameter("self_yaw_offset").as_double() * M_PI / 180.0;

    double tx_o = this->get_parameter("other_transform_x").as_double();
    double ty_o = this->get_parameter("other_transform_y").as_double();
    double tz_o = this->get_parameter("other_transform_z").as_double();
    double roll_o = this->get_parameter("other_roll_offset").as_double() * M_PI / 180.0;
    double pitch_o = this->get_parameter("other_pitch_offset").as_double() * M_PI / 180.0;
    double yaw_o = this->get_parameter("other_yaw_offset").as_double() * M_PI / 180.0;

    patch_cols_ = this->get_parameter("patch_cols").as_int();
    patch_rows_ = this->get_parameter("patch_rows").as_int();
    deg_thresh_ = this->get_parameter("deg_thresh").as_double();

    left_top_blind_.x = this->get_parameter("blind_left_top_x").as_double();
    left_top_blind_.y = this->get_parameter("blind_left_top_y").as_double();
    right_bottom_blind_.x = this->get_parameter("blind_right_bottom_x").as_double();
    right_bottom_blind_.y = this->get_parameter("blind_right_bottom_y").as_double();

    // 构建自车外参矩阵（从 LiDAR 坐标系到相机坐标系）
    Eigen::Matrix3d R_roll, R_pitch, R_yaw;
    R_roll << 1, 0, 0,
              0, cos(roll_s), -sin(roll_s),
              0, sin(roll_s), cos(roll_s);
    R_pitch << cos(pitch_s), 0, sin(pitch_s),
               0, 1, 0,
               -sin(pitch_s), 0, cos(pitch_s);
    R_yaw << cos(yaw_s), -sin(yaw_s), 0,
            sin(yaw_s), cos(yaw_s), 0,
            0, 0, 1;
    Eigen::Matrix3d R_base;
    R_base << 1, 0, 0,
              0, 0, 1,
              0, -1, 0;
    R_LC_self_ = R_yaw * R_pitch * R_roll * R_base;
    t_LC_self_ << tx_s, ty_s, tz_s;

    // 他车外参初始值（实际会被 /another_extrinsic 覆盖）
    R_roll << 1, 0, 0,
              0, cos(roll_o), -sin(roll_o),
              0, sin(roll_o), cos(roll_o);
    R_pitch << cos(pitch_o), 0, sin(pitch_o),
               0, 1, 0,
               -sin(pitch_o), 0, cos(pitch_o);
    R_yaw << cos(yaw_o), -sin(yaw_o), 0,
            sin(yaw_o), cos(yaw_o), 0,
            0, 0, 1;
    R_LC_other_ = R_yaw * R_pitch * R_roll * R_base;
    t_LC_other_ << tx_o, ty_o, tz_o;

    // 订阅器：自车内参
    info_self_sub_ = this->create_subscription<sensor_msgs::msg::CameraInfo>(
        "/sensing/camera/traffic_light/camera_info",
        rclcpp::SensorDataQoS(),
        std::bind(&SelfVehicleNode::info_self_callback, this, std::placeholders::_1));

    // 订阅器：他车内参和外参（transient_local）
    auto qos_transient = rclcpp::QoS(1).transient_local();
    info_other_sub_ = this->create_subscription<sensor_msgs::msg::CameraInfo>(
        "/another_intrinsic", qos_transient,
        std::bind(&SelfVehicleNode::info_other_callback, this, std::placeholders::_1));

    extrinsic_other_sub_ = this->create_subscription<geometry_msgs::msg::Transform>(
        "/another_extrinsic", qos_transient,
        std::bind(&SelfVehicleNode::extrinsic_other_callback, this, std::placeholders::_1));

    // 图像订阅：自车（末尾无1）和他车
    image_self_sub_ = this->create_subscription<sensor_msgs::msg::Image>(
        "/sensing/camera/traffic_light/image_raw",
        rclcpp::SensorDataQoS(),
        std::bind(&SelfVehicleNode::image_a_callback, this, std::placeholders::_1));

    image_b_sub_ = this->create_subscription<sensor_msgs::msg::Image>(
        "/another_image",
        rclcpp::SensorDataQoS(),
        std::bind(&SelfVehicleNode::image_b_callback, this, std::placeholders::_1));

    // 位姿订阅
    pose_self_sub_ = this->create_subscription<geometry_msgs::msg::PoseStamped>(
        "/sensing/gnss/pose",
        rclcpp::SensorDataQoS(),
        std::bind(&SelfVehicleNode::pose_a_callback, this, std::placeholders::_1));

    pose_other_sub_ = this->create_subscription<geometry_msgs::msg::PoseStamped>(
        "/another_pose",
        rclcpp::SensorDataQoS(),
        std::bind(&SelfVehicleNode::pose_b_callback, this, std::placeholders::_1));

    // 点云订阅
    cloud_b_sub_ = this->create_subscription<sensor_msgs::msg::PointCloud2>(
        "/another_cloud",
        rclcpp::SensorDataQoS(),
        std::bind(&SelfVehicleNode::points_callback, this, std::placeholders::_1));

    // 发布器：最终融合图像 + 单独的他车处理图像
    result_pub_ = image_transport::create_publisher(this, "/localize_image");
    another_processed_pub_ = image_transport::create_publisher(this, "/another_image_processed");
}

// ---------- 内参 / 外参回调 ----------
void SelfVehicleNode::info_self_callback(const sensor_msgs::msg::CameraInfo::SharedPtr msg)
{
    fx_self_ = msg->k[0];
    fy_self_ = msg->k[4];
    cx_self_ = msg->k[2];
    cy_self_ = msg->k[5];
    width_self_ = msg->width;
    height_self_ = msg->height;
    intrinsic_self_ready_ = true;
    RCLCPP_DEBUG(this->get_logger(), "Self camera info received.");
}

void SelfVehicleNode::info_other_callback(const sensor_msgs::msg::CameraInfo::SharedPtr msg)
{
    fx_other_ = msg->k[0];
    fy_other_ = msg->k[4];
    cx_other_ = msg->k[2];
    cy_other_ = msg->k[5];
    width_other_ = msg->width;
    height_other_ = msg->height;
    intrinsic_other_ready_ = true;
    RCLCPP_DEBUG(this->get_logger(), "Other camera info received.");
}

void SelfVehicleNode::extrinsic_other_callback(const geometry_msgs::msg::Transform::SharedPtr msg)
{
    tf2::Quaternion q;
    tf2::fromMsg(msg->rotation, q);
    tf2::Matrix3x3 rot(q);
    tf2::Vector3 trans(msg->translation.x, msg->translation.y, msg->translation.z);

    {
        std::lock_guard<std::mutex> lock(extrinsic_mutex_);
        for (int i = 0; i < 3; ++i)
            for (int j = 0; j < 3; ++j)
                R_LC_other_(i, j) = rot[i][j];
        t_LC_other_(0) = trans.x();
        t_LC_other_(1) = trans.y();
        t_LC_other_(2) = trans.z();
    }
    extrinsic_other_ready_ = true;
    RCLCPP_DEBUG(this->get_logger(), "Other extrinsic received.");
}

// ---------- 图像 / 位姿 缓存 ----------
void SelfVehicleNode::image_a_callback(const sensor_msgs::msg::Image::ConstSharedPtr msg)
{
    std::lock_guard<std::mutex> lock(data_mutex_);
    image_a_history_.push_back(msg);
    if (image_a_history_.size() > MAX_HISTORY) image_a_history_.pop_front();
}

void SelfVehicleNode::image_b_callback(const sensor_msgs::msg::Image::ConstSharedPtr msg)
{
    std::lock_guard<std::mutex> lock(data_mutex_);
    image_b_history_.push_back(msg);
    if (image_b_history_.size() > MAX_HISTORY) image_b_history_.pop_front();
}

void SelfVehicleNode::pose_a_callback(const geometry_msgs::msg::PoseStamped::ConstSharedPtr msg)
{
    auto corrected = std::make_shared<geometry_msgs::msg::PoseStamped>(*msg);
    // 强制四元数有效：若全零则设 w=1
    if (corrected->pose.orientation.x == 0.0 && corrected->pose.orientation.y == 0.0 &&
        corrected->pose.orientation.z == 0.0 && corrected->pose.orientation.w == 0.0) {
        corrected->pose.orientation.w = 1.0;
    }
    std::lock_guard<std::mutex> lock(data_mutex_);
    pose_a_history_.push_back(corrected);
    if (pose_a_history_.size() > MAX_HISTORY) pose_a_history_.pop_front();
}

void SelfVehicleNode::pose_b_callback(const geometry_msgs::msg::PoseStamped::ConstSharedPtr msg)
{
    auto corrected = std::make_shared<geometry_msgs::msg::PoseStamped>(*msg);
    if (corrected->pose.orientation.x == 0.0 && corrected->pose.orientation.y == 0.0 &&
        corrected->pose.orientation.z == 0.0 && corrected->pose.orientation.w == 0.0) {
        corrected->pose.orientation.w = 1.0;
    }
    std::lock_guard<std::mutex> lock(data_mutex_);
    pose_b_history_.push_back(corrected);
    if (pose_b_history_.size() > MAX_HISTORY) pose_b_history_.pop_front();
}

// ---------- 辅助函数 ----------
Eigen::Matrix3d SelfVehicleNode::quat_to_matrix(const geometry_msgs::msg::Quaternion& q)
{
    double norm_sq = q.x*q.x + q.y*q.y + q.z*q.z + q.w*q.w;
    if (norm_sq < EPS) {
        RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "Zero quaternion, using identity.");
        return Eigen::Matrix3d::Identity();
    }
    tf2::Quaternion tf_q(q.x, q.y, q.z, q.w);
    tf2::Matrix3x3 tf_m(tf_q);
    Eigen::Matrix3d m;
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j)
            m(i, j) = tf_m[i][j];
    return m;
}

bool SelfVehicleNode::in_image(double u, double v, int w, int h) const
{
    return u >= 0 && u < w && v >= 0 && v < h;
}

// 区域判定（复制自 try1）
int SelfVehicleNode::region_judge(const cv::Point2d& a, const cv::Point2d& b,
    const cv::Point2d& left_top, const cv::Point2d& right_bottom)
{
    bool a_in = (left_top.x - EPS < a.x && a.x < right_bottom.x + EPS &&
                 left_top.y - EPS < a.y && a.y < right_bottom.y + EPS);
    bool b_in = (left_top.x - EPS < b.x && b.x < right_bottom.x + EPS &&
                 left_top.y - EPS < b.y && b.y < right_bottom.y + EPS);
    if (!a_in && !b_in) return 0;
    if (a_in && !b_in) return 1;
    if (!a_in && b_in) return 2;
    return 3;
}

bool SelfVehicleNode::intersection_judge(const cv::Point2d& a, const cv::Point2d& b,
    const cv::Point2d& c, const cv::Point2d& d)
{
    if (std::min(a.x, b.x) > std::max(c.x, d.x) || std::min(c.x, d.x) > std::max(a.x, b.x) ||
        std::min(a.y, b.y) > std::max(c.y, d.y) || std::min(c.y, d.y) > std::max(a.y, b.y)) {
        return false;
    }
    auto cross = [](const cv::Point2d& o, const cv::Point2d& p, const cv::Point2d& q) {
        return (p.x - o.x) * (q.y - o.y) - (p.y - o.y) * (q.x - o.x);
    };
    double d1 = cross(a, b, c);
    double d2 = cross(a, b, d);
    double d3 = cross(c, d, a);
    double d4 = cross(c, d, b);
    return (d1 * d2 < 0 && d3 * d4 < 0);
}

cv::Point2d SelfVehicleNode::intersection(const cv::Point2d& a, const cv::Point2d& b,
    const cv::Point2d& c, const cv::Point2d& d)
{
    cv::Point2d v1 = b - a;
    cv::Point2d v2 = d - c;
    double det = v1.x * v2.y - v1.y * v2.x;
    if (std::abs(det) < EPS) return cv::Point2d(-1, -1);
    double t = ((c.x - a.x) * v2.y - (c.y - a.y) * v2.x) / det;
    double u = ((c.x - a.x) * v1.y - (c.y - a.y) * v1.x) / det;
    if (t >= 0 && t <= 1 && u >= 0 && u <= 1)
        return a + t * v1;
    return cv::Point2d(-1, -1);
}

cv::Point2d SelfVehicleNode::intersection_region(const cv::Point2d& p1, const cv::Point2d& p2,
    const cv::Point2d region_pts[4])
{
    for (int i = 0; i < 4; ++i) {
        if (intersection_judge(p1, p2, region_pts[i], region_pts[(i + 1) % 4])) {
            return intersection(p1, p2, region_pts[i], region_pts[(i + 1) % 4]);
        }
    }
    return cv::Point2d(-1, -1);
}

void SelfVehicleNode::intersection_region_2pts(const cv::Point2d& p1, const cv::Point2d& p2,
    const cv::Point2d region_pts[4],
    cv::Point2d result[2], double ratio[2])
{
    int cnt = 0;
    result[0] = cv::Point2d(-1, -1);
    result[1] = cv::Point2d(-1, -1);
    double dist_p1p2 = cv::norm(p1 - p2);
    if (dist_p1p2 < EPS) return;
    for (int i = 0; i < 4 && cnt < 2; ++i) {
        if (intersection_judge(p1, p2, region_pts[i], region_pts[(i + 1) % 4])) {
            cv::Point2d inter = intersection(p1, p2, region_pts[i], region_pts[(i + 1) % 4]);
            if (inter.x < 0) continue;
            if (cnt == 0) {
                result[0] = inter;
                ratio[0] = cv::norm(inter - p1) / dist_p1p2;
                cnt++;
            } else {
                result[1] = inter;
                ratio[1] = cv::norm(inter - p1) / dist_p1p2;
                cnt++;
            }
        }
    }
    if (cnt == 2 && ratio[0] > ratio[1]) {
        std::swap(result[0], result[1]);
        std::swap(ratio[0], ratio[1]);
    }
}

// 解析点云（保持原有实现，但需要为 PointData 填充 azimuth, u_a, v_a, u_b, v_b, valid）
void SelfVehicleNode::parse_pointcloud(
    const sensor_msgs::msg::PointCloud2::ConstSharedPtr& cloud,
    std::map<uint16_t, std::vector<PointData>>& out_map)
{
    // 查找字段偏移量
    int off_x = -1, off_y = -1, off_z = -1, off_ch = -1;
    uint8_t ch_datatype = 0;
    for (const auto& f : cloud->fields) {
        if (f.name == "x") off_x = f.offset;
        else if (f.name == "y") off_y = f.offset;
        else if (f.name == "z") off_z = f.offset;
        else if (f.name == "channel") { off_ch = f.offset; ch_datatype = f.datatype; }
    }
    if (off_x < 0 || off_y < 0 || off_z < 0 || off_ch < 0) {
        RCLCPP_ERROR(this->get_logger(), "Missing fields in point cloud.");
        return;
    }

    const uint8_t* data = cloud->data.data();
    size_t point_count = cloud->width * cloud->height;
    for (size_t i = 0; i < point_count; ++i) {
        const uint8_t* ptr = data + i * cloud->point_step;
        float x, y, z;
        std::memcpy(&x, ptr + off_x, sizeof(float));
        std::memcpy(&y, ptr + off_y, sizeof(float));
        std::memcpy(&z, ptr + off_z, sizeof(float));

        uint16_t ch = 0;
        if (ch_datatype == sensor_msgs::msg::PointField::UINT16) {
            std::memcpy(&ch, ptr + off_ch, sizeof(uint16_t));
        } else if (ch_datatype == sensor_msgs::msg::PointField::FLOAT32) {
            float ch_f;
            std::memcpy(&ch_f, ptr + off_ch, sizeof(float));
            if (!std::isfinite(ch_f) || ch_f < 0) continue;
            ch = static_cast<uint16_t>(ch_f);
        } else continue;

        if (!std::isfinite(x) || !std::isfinite(y) || !std::isfinite(z)) continue;

        // Unity -> ROS 坐标系转换（与原始代码一致）
        float ros_x =  z;
        float ros_y = -x;
        float ros_z =  y;

        PointData p;
        p.x = ros_x; p.y = ros_y; p.z = ros_z;
        p.azimuth = atan2(ros_y, ros_x);
        p.u_a = 0; p.v_a = 0;
        p.u_b = 0; p.v_b = 0;
        p.channel = ch;
        p.valid = false;
        out_map[ch].push_back(p);
    }
}

// 处理相邻两点之间的纹理粘贴（复制自 try1 的 processSegment，稍作适配）
bool SelfVehicleNode::processSegment(const PointData& prev, const PointData& cur,
    const cv::Mat& img_b, const cv::Point2d blind_pts[4],
    cv::Mat& output)
{
    double rad_diff = std::abs(cur.azimuth - prev.azimuth);
    rad_diff = std::min(rad_diff, 2 * M_PI - rad_diff);
    double deg_diff = rad_diff * 180.0 / M_PI;
    if (deg_diff < deg_thresh_) return false;

    int judge = region_judge(cv::Point2d(prev.u_a, prev.v_a),
                             cv::Point2d(cur.u_a, cur.v_a),
                             left_top_blind_, right_bottom_blind_);

    // 从 he 车图像提取旋转矩形 patch
    cv::Point2d center_b((prev.u_b + cur.u_b) / 2, (prev.v_b + cur.v_b) / 2);
    double angle_b_rad = atan2(cur.v_b - prev.v_b, cur.u_b - prev.u_b);
    double angle_b_deg = angle_b_rad * 180.0 / M_PI;
    double dist_b = cv::norm(cv::Point2d(cur.u_b - prev.u_b, cur.v_b - prev.v_b));
    if (dist_b < EPS) return false;
    cv::Size rect_size(static_cast<int>(std::round(dist_b)), patch_rows_);
    cv::RotatedRect rect_b_rot(center_b, rect_size, angle_b_deg);
    cv::Mat rotated;
    cv::Mat rmat = cv::getRotationMatrix2D(rect_b_rot.center, angle_b_deg, 1.0);
    cv::warpAffine(img_b, rotated, rmat, img_b.size(), cv::INTER_NEAREST);
    cv::Mat patch_b;
    cv::getRectSubPix(rotated, rect_size, rect_b_rot.center, patch_b);

    cv::Point2f src_pts[3] = {
        cv::Point2f(0, 0),
        cv::Point2f(patch_b.cols, 0),
        cv::Point2f(0, patch_b.rows)
    };

    cv::Point2d start_a, end_a;
    bool valid = false;

    if (judge == 0) {
        cv::Point2d result_pts[2];
        double ratio[2];
        intersection_region_2pts(cv::Point2d(prev.u_a, prev.v_a),
                                 cv::Point2d(cur.u_a, cur.v_a),
                                 blind_pts, result_pts, ratio);
        if (result_pts[0].x > 0 && result_pts[1].x > 0) {
            start_a = result_pts[0];
            end_a = result_pts[1];
            valid = true;
        }
    } else if (judge == 1) {
        cv::Point2d inter = intersection_region(cv::Point2d(prev.u_a, prev.v_a),
                                                cv::Point2d(cur.u_a, cur.v_a),
                                                blind_pts);
        if (inter.x > 0) {
            start_a = inter;
            end_a = cv::Point2d(cur.u_a, cur.v_a);
            valid = true;
        }
    } else if (judge == 2) {
        cv::Point2d inter = intersection_region(cv::Point2d(prev.u_a, prev.v_a),
                                                cv::Point2d(cur.u_a, cur.v_a),
                                                blind_pts);
        if (inter.x > 0) {
            start_a = cv::Point2d(prev.u_a, prev.v_a);
            end_a = inter;
            valid = true;
        }
    } else { // judge == 3
        start_a = cv::Point2d(prev.u_a, prev.v_a);
        end_a = cv::Point2d(cur.u_a, cur.v_a);
        valid = true;
    }

    if (!valid) return false;

    cv::Point2d vec_a = end_a - start_a;
    double len_a = cv::norm(vec_a);
    if (len_a < EPS) return false;
    cv::Point2d dir_a = vec_a / len_a;
    cv::Point2d perp_a = cv::Point2d(-dir_a.y, dir_a.x);
    cv::Point2d center_a = (start_a + end_a) / 2.0;
    double half_width = patch_rows_ / 2.0;
    double half_len = len_a / 2.0;

    cv::Point2f dst_pts[3];
    dst_pts[0] = cv::Point2f(center_a.x - half_len * dir_a.x - half_width * perp_a.x,
                             center_a.y - half_len * dir_a.y - half_width * perp_a.y);
    dst_pts[1] = cv::Point2f(center_a.x + half_len * dir_a.x - half_width * perp_a.x,
                             center_a.y + half_len * dir_a.y - half_width * perp_a.y);
    dst_pts[2] = cv::Point2f(center_a.x - half_len * dir_a.x + half_width * perp_a.x,
                             center_a.y - half_len * dir_a.y + half_width * perp_a.y);

    // 边界检查
    if (patch_b.rows > 0 && patch_b.cols > 0 &&
        dst_pts[0].x >= 0 && dst_pts[0].x < output.cols &&
        dst_pts[0].y >= 0 && dst_pts[0].y < output.rows &&
        dst_pts[1].x >= 0 && dst_pts[1].x < output.cols &&
        dst_pts[1].y >= 0 && dst_pts[1].y < output.rows &&
        dst_pts[2].x >= 0 && dst_pts[2].x < output.cols &&
        dst_pts[2].y >= 0 && dst_pts[2].y < output.rows) {
        cv::Mat affine_mat = cv::getAffineTransform(src_pts, dst_pts);
        cv::warpAffine(patch_b, output, affine_mat, output.size(),
                       cv::INTER_NEAREST, cv::BORDER_TRANSPARENT);
        return true;
    }
    return false;
}

// ---------- 核心点云处理 ----------
void SelfVehicleNode::points_callback(const sensor_msgs::msg::PointCloud2::ConstSharedPtr cloud_b)
{
    // 1. 同步数据
    sensor_msgs::msg::Image::ConstSharedPtr image_a, image_b;
    geometry_msgs::msg::PoseStamped::ConstSharedPtr pose_a, pose_b;
    bool exact_a, exact_b, exact_pose_a, exact_pose_b;
    {
        std::lock_guard<std::mutex> lock(data_mutex_);
        if (!getClosest(image_a_history_, cloud_b->header.stamp, image_a, SYNC_MAX_TIME_DIFF, exact_a) ||
            !getClosest(image_b_history_, cloud_b->header.stamp, image_b, SYNC_MAX_TIME_DIFF, exact_b) ||
            !getClosest(pose_a_history_, cloud_b->header.stamp, pose_a, SYNC_MAX_TIME_DIFF, exact_pose_a) ||
            !getClosest(pose_b_history_, cloud_b->header.stamp, pose_b, SYNC_MAX_TIME_DIFF, exact_pose_b)) {
            static bool warn = true;
            if (warn) { RCLCPP_WARN(this->get_logger(), "Missing sync data."); warn = false; }
            return;
        }
    }

    if (!intrinsic_self_ready_ || !intrinsic_other_ready_ || !extrinsic_other_ready_) {
        RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "Waiting for intrinsic/extrinsic.");
        return;
    }

    // 2. 拷贝外参
    Eigen::Matrix3d R_LC_other;
    Eigen::Vector3d t_LC_other;
    {
        std::lock_guard<std::mutex> lock(extrinsic_mutex_);
        R_LC_other = R_LC_other_;
        t_LC_other = t_LC_other_;
    }

    // 3. 位姿变换
    Eigen::Vector3d t_WA(pose_a->pose.position.x, pose_a->pose.position.y, pose_a->pose.position.z);
    Eigen::Matrix3d R_WA = quat_to_matrix(pose_a->pose.orientation);
    Eigen::Matrix3d R_AW = R_WA.transpose();

    Eigen::Vector3d t_WB(pose_b->pose.position.x, pose_b->pose.position.y, pose_b->pose.position.z);
    Eigen::Matrix3d R_WB = quat_to_matrix(pose_b->pose.orientation);

    // 4. 解析点云
    std::map<uint16_t, std::vector<PointData>> points_by_ch;
    parse_pointcloud(cloud_b, points_by_ch);

    // 5. 转换图像
    cv::Mat img_a, img_b;
    try {
        img_a = cv_bridge::toCvCopy(image_a, "bgr8")->image;
        img_b = cv_bridge::toCvCopy(image_b, "bgr8")->image;
    } catch (const cv_bridge::Exception& e) {
        RCLCPP_ERROR(this->get_logger(), "cv_bridge error: %s", e.what());
        return;
    }

    cv::Mat output = img_a.clone();            // 最终融合结果
    cv::Mat another_processed = img_b.clone(); // 他车图像处理结果（单独发布）

    cv::Point2d blind_pts[4] = {
        left_top_blind_,
        cv::Point2d(right_bottom_blind_.x, left_top_blind_.y),
        right_bottom_blind_,
        cv::Point2d(left_top_blind_.x, right_bottom_blind_.y)
    };

    // 6. 对每个通道处理点云
    for (auto& [ch, vec] : points_by_ch) {
        if (vec.empty()) continue;

        // 按方位角排序
        std::sort(vec.begin(), vec.end(),
                  [](const PointData& a, const PointData& b) { return a.azimuth < b.azimuth; });

        // 计算投影坐标
        for (auto& p : vec) {
            Eigen::Vector3d p_bl(p.x, p.y, p.z);

            // 自车投影
            Eigen::Vector3d p_w = R_WB * p_bl + t_WB;
            Eigen::Vector3d p_al = R_AW * (p_w - t_WA);
            Eigen::Vector3d p_ac = R_LC_self_ * p_al + t_LC_self_;
            if (p_ac.z() <= 0) continue;
            double u_a = fx_self_ * p_ac.x() / p_ac.z() + cx_self_;
            double v_a = fy_self_ * p_ac.y() / p_ac.z() + cy_self_;
            if (!in_image(u_a, v_a, width_self_, height_self_)) continue;

            // 他车投影
            Eigen::Vector3d p_bc = R_LC_other * p_bl + t_LC_other;
            if (p_bc.z() <= 0) continue;
            double u_b = fx_other_ * p_bc.x() / p_bc.z() + cx_other_;
            double v_b = fy_other_ * p_bc.y() / p_bc.z() + cy_other_;
            if (!in_image(u_b, v_b, width_other_, height_other_)) continue;

            p.u_a = u_a; p.v_a = v_a;
            p.u_b = u_b; p.v_b = v_b;
            p.valid = true;
        }

        // 移除无效点
        vec.erase(std::remove_if(vec.begin(), vec.end(),
                                 [](const PointData& p) { return !p.valid; }),
                  vec.end());
        if (vec.size() < 2) continue;

        // 遍历相邻点对，进行盲区填补
        for (size_t i = 0; i < vec.size() - 1; ++i) {
            processSegment(vec[i], vec[i+1], img_b, blind_pts, output);
        }
        // 处理首尾环回
        const auto& first = vec.front();
        const auto& last = vec.back();
        double rad_diff = std::abs(first.azimuth - last.azimuth);
        rad_diff = std::min(rad_diff, 2 * M_PI - rad_diff);
        if (rad_diff * 180.0 / M_PI >= deg_thresh_) {
            processSegment(last, first, img_b, blind_pts, output);
        }

        // 后备：对每个有效点，直接拷贝一个小矩形（用于未欠损区域）
        for (const auto& p : vec) {
            int half_cols = patch_cols_ / 2;
            int half_rows = patch_rows_ / 2;
            int u_b_int = static_cast<int>(std::round(p.u_b));
            int v_b_int = static_cast<int>(std::round(p.v_b));
            int u_a_int = static_cast<int>(std::round(p.u_a));
            int v_a_int = static_cast<int>(std::round(p.v_a));

            cv::Rect rect_b(u_b_int - half_cols, v_b_int - half_rows, patch_cols_, patch_rows_);
            cv::Rect rect_a(u_a_int - half_cols, v_a_int - half_rows, patch_cols_, patch_rows_);
            rect_b = rect_b & cv::Rect(0, 0, width_other_, height_other_);
            rect_a = rect_a & cv::Rect(0, 0, width_self_, height_self_);
            if (rect_b.area() > 0 && rect_a.area() > 0) {
                cv::Mat patch = img_b(rect_b).clone();
                patch.copyTo(output(rect_a));
            }
        }

        // ---------- 单独处理他车图像：在他车图像上绘制投影点（可选） ----------
        // 为了展示点云在他车图像上的投影，可以画圆（类似原始功能）
        for (const auto& p : vec) {
            cv::circle(another_processed, cv::Point(static_cast<int>(p.u_b), static_cast<int>(p.v_b)), 3, cv::Scalar(0, 255, 0), -1);
        }
        // 也可以将提取的 patch 贴回他车图像（高亮显示），但这里仅画点作为示例
    }

    // 7. 发布结果
    auto out_msg = cv_bridge::CvImage(image_a->header, "bgr8", output).toImageMsg();
    result_pub_.publish(out_msg);

    auto another_msg = cv_bridge::CvImage(image_b->header, "bgr8", another_processed).toImageMsg();
    another_processed_pub_.publish(another_msg);
}

} // namespace self_vehicle

int main(int argc, char* argv[])
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<self_vehicle::SelfVehicleNode>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}