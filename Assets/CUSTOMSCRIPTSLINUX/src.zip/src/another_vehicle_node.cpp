#include "another_vehicle.hpp"
#include <cv_bridge/cv_bridge.h>
#include <algorithm>
#include <cmath>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>

namespace another_vehicle
{

    AnotherVehicleNode::AnotherVehicleNode() : Node("another_vehicle")
    {
        this->declare_parameter("transform_x", 0.0);
        this->declare_parameter("transform_y", 0.0);
        this->declare_parameter("transform_z", 0.0);
        this->declare_parameter("roll_offset", 0.0);
        this->declare_parameter("pitch_offset", 0.0);
        this->declare_parameter("yaw_offset", 0.0);
        this->declare_parameter("FOV", 84.9);
        this->declare_parameter("max_range", 120.0);
        this->declare_parameter("vlp16_angles", std::vector<double>{
            -15.0, 1.0, -13.0, 3.0, -11.0, 5.0, -9.0, 7.0,
                -7.0, 9.0, -5.0, 11.0, -3.0, 13.0, -1.0, 15.0});

        transform_x_ = this->get_parameter("transform_x").as_double();
        transform_y_ = this->get_parameter("transform_y").as_double();
        transform_z_ = this->get_parameter("transform_z").as_double();
        roll_offset_ = this->get_parameter("roll_offset").as_double();
        pitch_offset_ = this->get_parameter("pitch_offset").as_double();
        yaw_offset_ = this->get_parameter("yaw_offset").as_double();
        double fov = this->get_parameter("FOV").as_double();
        max_tan_ = tan(fov * 0.5 * M_PI / 180.0);
        max_range_ = this->get_parameter("max_range").as_double();
        auto angles_deg = this->get_parameter("vlp16_angles").as_double_array();
        for (size_t i = 0; i < 16 && i < angles_deg.size(); ++i) {
            vert_angle_[i] = angles_deg[i] * M_PI / 180.0;
        }
        for (size_t i = 16; i < 32; ++i) vert_angle_[i] = 0.0;

        phi_left_ = atan2(-1.0, max_tan_);
        phi_right_ = atan2(1.0, max_tan_);

        // 订阅B车话题（均已加1）
        points_sub_ = this->create_subscription<sensor_msgs::msg::PointCloud2>(
            "/sensing/lidar/top/pointcloud_raw_ex1",
            rclcpp::QoS(5).best_effort(),
            std::bind(&AnotherVehicleNode::points_callback, this, std::placeholders::_1));

        info_sub_ = this->create_subscription<sensor_msgs::msg::CameraInfo>(
            "/sensing/camera/traffic_light/camera_info1",
            rclcpp::QoS(1).best_effort(),
            std::bind(&AnotherVehicleNode::info_callback, this, std::placeholders::_1));

        image_sub_ = image_transport::create_subscription(
            this, "/sensing/camera/traffic_light/image_raw1",
            std::bind(&AnotherVehicleNode::image_callback, this, std::placeholders::_1),
            "raw", rclcpp::QoS(1).best_effort().get_rmw_qos_profile());

        pose_sub_ = this->create_subscription<geometry_msgs::msg::PoseStamped>(
            "/sensing/gnss/pose1",
            10,
            std::bind(&AnotherVehicleNode::pose_callback, this, std::placeholders::_1));

        // 外参话题（非AWSIM，保持原样）
        extrinsic_sub_ = this->create_subscription<geometry_msgs::msg::Transform>(
            "/ano/projection_matrix", 1,
            std::bind(&AnotherVehicleNode::extrinsic_callback, this, std::placeholders::_1));

        auto qos_transient = rclcpp::QoS(1).transient_local();
        cloud_pub_ = this->create_publisher<sensor_msgs::msg::PointCloud2>("/another_cloud", 10);
        image_pub_ = image_transport::create_publisher(this, "/another_image");
        pose_pub_ = this->create_publisher<geometry_msgs::msg::PoseStamped>("/another_pose", 10);
        extrinsic_pub_ = this->create_publisher<geometry_msgs::msg::Transform>("/another_extrinsic", qos_transient);
        intrinsic_pub_ = this->create_publisher<sensor_msgs::msg::CameraInfo>("/another_intrinsic", qos_transient);
        ring_count_pub_ = this->create_publisher<std_msgs::msg::Int16MultiArray>("/ring_count", 10);

        // B车点云frame_id加1
        another_cloud_.header.frame_id = "velodyne_top1";
        another_cloud_.height = 1;
        another_cloud_.fields.clear();
        sensor_msgs::msg::PointField f;
        f.name = "x"; f.offset = 0; f.datatype = sensor_msgs::msg::PointField::FLOAT32; f.count = 1;
        another_cloud_.fields.push_back(f);
        f.name = "y"; f.offset = 4; f.datatype = sensor_msgs::msg::PointField::FLOAT32; f.count = 1;
        another_cloud_.fields.push_back(f);
        f.name = "z"; f.offset = 8; f.datatype = sensor_msgs::msg::PointField::FLOAT32; f.count = 1;
        another_cloud_.fields.push_back(f);
        f.name = "channel"; f.offset = 12; f.datatype = sensor_msgs::msg::PointField::FLOAT32; f.count = 1;
        another_cloud_.fields.push_back(f);
        another_cloud_.point_step = 16;
        another_cloud_.is_bigendian = false;
        another_cloud_.is_dense = true;

        // 使用参数构建默认外参
        tf2::Matrix3x3 rotation_base;
        rotation_base.setValue(1, 0, 0, 0, 0, 1, 0, -1, 0);
        tf2::Quaternion q_roll, q_pitch, q_yaw;
        q_roll.setRPY(roll_offset_ * M_PI / 180.0, 0, 0);
        q_pitch.setRPY(0, pitch_offset_ * M_PI / 180.0, 0);
        q_yaw.setRPY(0, 0, yaw_offset_ * M_PI / 180.0);
        tf2::Matrix3x3 rotation_offset = tf2::Matrix3x3(q_yaw) * tf2::Matrix3x3(q_pitch) * tf2::Matrix3x3(q_roll);
        tf2::Matrix3x3 rotation_final = rotation_offset * rotation_base;

        {
            std::lock_guard<std::mutex> lock(extrinsic_mutex_);
            for (int i = 0; i < 3; ++i) {
                for (int j = 0; j < 3; ++j) {
                    R_LC_(i, j) = rotation_final[i][j];
                }
            }
            t_LC_(0) = transform_x_;
            t_LC_(1) = transform_y_;
            t_LC_(2) = transform_z_;
            Eigen::Vector3d neg_t = -t_LC_;
            Eigen::Vector3d inv_rt = R_LC_.transpose() * neg_t;
            inv_rt_LC_[0] = inv_rt(0);
            inv_rt_LC_[1] = inv_rt(1);
            inv_rt_LC_[2] = inv_rt(2);
        }

        geometry_msgs::msg::Transform default_extrinsic;
        tf2::Matrix3x3 rot(rotation_final[0][0], rotation_final[0][1], rotation_final[0][2],
            rotation_final[1][0], rotation_final[1][1], rotation_final[1][2],
            rotation_final[2][0], rotation_final[2][1], rotation_final[2][2]);
        tf2::Quaternion q;
        rot.getRotation(q);
        default_extrinsic.rotation = tf2::toMsg(q);
        default_extrinsic.translation.x = transform_x_;
        default_extrinsic.translation.y = transform_y_;
        default_extrinsic.translation.z = transform_z_;

        extrinsic_pub_->publish(default_extrinsic);
        projection_flag_ = true;
    }

    void AnotherVehicleNode::info_callback(const sensor_msgs::msg::CameraInfo::SharedPtr msg)
    {
        fx_ = msg->k[0];
        fy_ = msg->k[4];
        cx_ = msg->k[2];
        cy_ = msg->k[5];
        width_ = msg->width;
        height_ = msg->height;
        intrinsic_flag_ = true;
        intrinsic_pub_->publish(*msg);
        RCLCPP_INFO(this->get_logger(), "B camera info received and published.");
    }

    void AnotherVehicleNode::image_callback(const sensor_msgs::msg::Image::ConstSharedPtr msg)
    {
        if (msg->data.empty()) {
            RCLCPP_WARN(this->get_logger(), "Received empty image.");
            return;
        }
        {
            std::lock_guard<std::mutex> lock(last_image_mutex_);
            last_image_ = msg;
        }
        image_flag_ = true;
    }

    void AnotherVehicleNode::pose_callback(const geometry_msgs::msg::PoseStamped::SharedPtr msg)
    {
        {
            std::lock_guard<std::mutex> lock(pose_mutex_);
            pose_history_.push_back(*msg);
            if (pose_history_.size() > MAX_POSE_HISTORY) {
                pose_history_.pop_front();
            }
        }

        // 安全赋值（替换 memcpy）
        transform_WL_[0] = msg->pose.position.x;
        transform_WL_[1] = msg->pose.position.y;
        transform_WL_[2] = msg->pose.position.z;

        orientation_WL_[0] = msg->pose.orientation.x;
        orientation_WL_[1] = msg->pose.orientation.y;
        orientation_WL_[2] = msg->pose.orientation.z;
        orientation_WL_[3] = msg->pose.orientation.w;

        tf2::Quaternion q(
            msg->pose.orientation.x,
            msg->pose.orientation.y,
            msg->pose.orientation.z,
            msg->pose.orientation.w);

        tf2::Matrix3x3 m(q);
        for (int i = 0; i < 3; ++i)
            for (int j = 0; j < 3; ++j)
                rotation_WL_[i * 3 + j] = m[i][j];

        pose_flag_ = true;
    }

    void AnotherVehicleNode::extrinsic_callback(const geometry_msgs::msg::Transform::SharedPtr msg)
    {
        tf2::Quaternion q;
        tf2::fromMsg(msg->rotation, q);
        tf2::Matrix3x3 rot(q);
        tf2::Vector3 trans(msg->translation.x, msg->translation.y, msg->translation.z);

        {
            std::lock_guard<std::mutex> lock(extrinsic_mutex_);
            for (int i = 0; i < 3; ++i) {
                for (int j = 0; j < 3; ++j) {
                    R_LC_(i, j) = rot[i][j];
                }
            }
            t_LC_(0) = trans.x();
            t_LC_(1) = trans.y();
            t_LC_(2) = trans.z();

            Eigen::Vector3d neg_t = -t_LC_;
            Eigen::Vector3d inv_rt = R_LC_.transpose() * neg_t;
            inv_rt_LC_[0] = inv_rt(0);
            inv_rt_LC_[1] = inv_rt(1);
            inv_rt_LC_[2] = inv_rt(2);
        }

        projection_flag_ = true;
    }

    bool AnotherVehicleNode::getPoseAtTime(
        const rclcpp::Time& stamp,
        geometry_msgs::msg::PoseStamped& out_pose) const
    {
        std::lock_guard<std::mutex> lock(pose_mutex_);
        if (pose_history_.empty()) return false;

        auto best_it = pose_history_.rbegin();
        double best_diff = std::abs(
            (rclcpp::Time(best_it->header.stamp) - stamp).seconds());

        for (auto it = pose_history_.rbegin(); it != pose_history_.rend(); ++it) {
            double diff = std::abs(
                (rclcpp::Time(it->header.stamp) - stamp).seconds());

            if (diff < best_diff) {
                best_diff = diff;
                best_it = it;
            }
        }

        if (best_diff > 0.3) {
            return false;
        }

        out_pose = *best_it;
        return true;
    }

    void AnotherVehicleNode::points_callback(
        const sensor_msgs::msg::PointCloud2::SharedPtr msg)
    {
        if (!projection_flag_ || !intrinsic_flag_ || !pose_flag_) {
            return;
        }

        // ===== 取外参 =====
        Eigen::Matrix3d R_LC;
        Eigen::Vector3d t_LC;
        double inv_rt_LC[3];

        {
            std::lock_guard<std::mutex> lock(extrinsic_mutex_);
            R_LC = R_LC_;
            t_LC = t_LC_;
            memcpy(inv_rt_LC, inv_rt_LC_, sizeof(inv_rt_LC_));
        }

        // ===== 字段解析 =====
        int off_x = -1, off_y = -1, off_z = -1, off_ch = -1;
        uint8_t channel_datatype = 0;

        for (const auto& f : msg->fields) {
            if (f.name == "x") off_x = f.offset;
            else if (f.name == "y") off_y = f.offset;
            else if (f.name == "z") off_z = f.offset;
            else if (f.name == "channel") {
                off_ch = f.offset;
                channel_datatype = f.datatype;
            }
        }

        if (off_x < 0 || off_y < 0 || off_z < 0 || off_ch < 0) {
            RCLCPP_ERROR(this->get_logger(), "Missing required fields.");
            return;
        }

        if (msg->point_step < 16) {
            RCLCPP_ERROR(this->get_logger(), "Invalid point_step.");
            return;
        }

        if (off_x + 4 > msg->point_step ||
            off_y + 4 > msg->point_step ||
            off_z + 4 > msg->point_step ||
            off_ch + 2 > msg->point_step) {
            RCLCPP_ERROR(this->get_logger(), "Field offset out of bounds.");
            return;
        }

        // ===== pose 同步（带 fallback）=====
        geometry_msgs::msg::PoseStamped matched_pose;

        if (!getPoseAtTime(msg->header.stamp, matched_pose)) {
            std::lock_guard<std::mutex> lock(pose_mutex_);
            if (!pose_history_.empty()) {
                matched_pose = pose_history_.back();  // fallback
            }
            else {
                return;
            }
        }

        // ===== 点云遍历（修复版）=====
        const uint8_t* ptr = msg->data.data();
        const uint8_t* end_ptr = ptr + msg->data.size();

        size_t total_points = msg->width * msg->height;

        std::vector<float> buf_cloud;
        buf_cloud.reserve(total_points * 4);

        for (size_t i = 0; i < total_points; ++i) {

            if (ptr + msg->point_step > end_ptr) {
                RCLCPP_WARN(this->get_logger(), "Point cloud truncated.");
                break;
            }

            float x = *reinterpret_cast<const float*>(ptr + off_x);
            float y = *reinterpret_cast<const float*>(ptr + off_y);
            float z = *reinterpret_cast<const float*>(ptr + off_z);

            uint16_t ch;
            if (channel_datatype == sensor_msgs::msg::PointField::UINT16) {
                ch = *reinterpret_cast<const uint16_t*>(ptr + off_ch);
            }
            else {
                ch = static_cast<uint16_t>(
                    *reinterpret_cast<const float*>(ptr + off_ch));
            }

            if (ch >= 32) {
                ptr += msg->point_step;
                continue;
            }

            Eigen::Vector3d p_l(x, y, z);
            Eigen::Vector3d p_c = R_LC * p_l + t_LC;

            if (p_c.z() <= 0) {
                ptr += msg->point_step;
                continue;
            }

            double u = fx_ * p_c.x() / p_c.z() + cx_;
            double v = fy_ * p_c.y() / p_c.z() + cy_;

            if (u < 0 || u >= width_ || v < 0 || v >= height_) {
                ptr += msg->point_step;
                continue;
            }

            buf_cloud.push_back(x);
            buf_cloud.push_back(y);
            buf_cloud.push_back(z);
            buf_cloud.push_back(static_cast<float>(ch));

            ptr += msg->point_step;
        }

        // ===== 发布点云 =====
        another_cloud_.header.stamp = msg->header.stamp;

        if (!buf_cloud.empty()) {
            another_cloud_.width = buf_cloud.size() / 4;
            another_cloud_.data.resize(buf_cloud.size() * sizeof(float));
            memcpy(another_cloud_.data.data(), buf_cloud.data(),
                buf_cloud.size() * sizeof(float));
        }
        else {
            another_cloud_.width = 0;
            another_cloud_.data.clear();
        }

        another_cloud_.row_step = another_cloud_.data.size();

        cloud_pub_->publish(another_cloud_);

// ===== 图像（对齐点云时间）=====
{
    std::lock_guard<std::mutex> lock(last_image_mutex_);
    if (last_image_) {
        auto img = *last_image_;
        img.header.stamp = msg->header.stamp;
        image_pub_.publish(img);
    }
}

        // ===== pose =====
        geometry_msgs::msg::PoseStamped pose_msg = matched_pose;
        pose_msg.header.stamp = msg->header.stamp;
        pose_pub_->publish(pose_msg);

        frame_count_++;
    }
}

int main(int argc, char* argv[])
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<another_vehicle::AnotherVehicleNode>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}