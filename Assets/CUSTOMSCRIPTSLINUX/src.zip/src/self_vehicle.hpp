#ifndef SELF_VEHICLE_HPP
#define SELF_VEHICLE_HPP

#include <rclcpp/rclcpp.hpp>
#include <rclcpp/qos.hpp>

#include <sensor_msgs/msg/point_cloud2.hpp>
#include <sensor_msgs/msg/image.hpp>
#include <sensor_msgs/msg/camera_info.hpp>
#include <sensor_msgs/msg/point_field.hpp>

#include <geometry_msgs/msg/pose_stamped.hpp>
#include <geometry_msgs/msg/transform.hpp>
#include <geometry_msgs/msg/quaternion.hpp>

#include <image_transport/image_transport.hpp>
#include <cv_bridge/cv_bridge.h>
#include <opencv2/opencv.hpp>

#include <Eigen/Dense>

#include <tf2/LinearMath/Quaternion.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>

#include <algorithm>
#include <cmath>
#include <deque>
#include <map>
#include <vector>
#include <mutex>
#include <cstring>

namespace self_vehicle
{

    struct PointData
    {
        float x, y, z;
        double azimuth;

        double u_b, v_b;
        double u_a, v_a;

        uint16_t channel;
        bool valid = false;
    };

    struct PrevPointData
    {
        double u_b, v_b;
        double u_a, v_a;
        double azimuth;
        bool valid = false;
    };

    class SelfVehicleNode : public rclcpp::Node
    {
    public:
        SelfVehicleNode();

    private:
        // ===== 内参 / 外参回调 =====
        void info_self_callback(const sensor_msgs::msg::CameraInfo::SharedPtr msg);
        void info_other_callback(const sensor_msgs::msg::CameraInfo::SharedPtr msg);
        void extrinsic_other_callback(const geometry_msgs::msg::Transform::SharedPtr msg);

        // ===== 数据缓存回调（只存储） =====
        void image_a_callback(const sensor_msgs::msg::Image::ConstSharedPtr msg);
        void image_b_callback(const sensor_msgs::msg::Image::ConstSharedPtr msg);
        void pose_a_callback(const geometry_msgs::msg::PoseStamped::ConstSharedPtr msg);
        void pose_b_callback(const geometry_msgs::msg::PoseStamped::ConstSharedPtr msg);

        // ===== 点云驱动主处理 =====
        void points_callback(const sensor_msgs::msg::PointCloud2::ConstSharedPtr cloud_b);

        // ===== 核心处理函数 =====
        void parse_pointcloud(
            const sensor_msgs::msg::PointCloud2::ConstSharedPtr& cloud,
            std::map<uint16_t, std::vector<PointData>>& out_map);

        bool processSegment(
            const PointData& prev,
            const PointData& cur,
            const cv::Mat& img_b,
            const cv::Point2d blind_pts[4],
            cv::Mat& output);

        // ===== 几何辅助函数 =====
        int region_judge(
            const cv::Point2d& a,
            const cv::Point2d& b,
            const cv::Point2d& left_top,
            const cv::Point2d& right_bottom);

        bool intersection_judge(
            const cv::Point2d& a,
            const cv::Point2d& b,
            const cv::Point2d& c,
            const cv::Point2d& d);

        cv::Point2d intersection(
            const cv::Point2d& a,
            const cv::Point2d& b,
            const cv::Point2d& c,
            const cv::Point2d& d);

        cv::Point2d intersection_region(
            const cv::Point2d& p1,
            const cv::Point2d& p2,
            const cv::Point2d region_pts[4]);

        void intersection_region_2pts(
            const cv::Point2d& p1,
            const cv::Point2d& p2,
            const cv::Point2d region_pts[4],
            cv::Point2d result[2],
            double ratio[2]);

        bool in_image(double u, double v, int w, int h) const;
        Eigen::Matrix3d quat_to_matrix(const geometry_msgs::msg::Quaternion& q);

        // ===== 外参 =====
        Eigen::Matrix3d R_LC_self_;
        Eigen::Vector3d t_LC_self_;

        mutable std::mutex extrinsic_mutex_;
        Eigen::Matrix3d R_LC_other_;
        Eigen::Vector3d t_LC_other_;

        // ===== 相机内参 =====
        double fx_self_ = 0.0, fy_self_ = 0.0;
        double cx_self_ = 0.0, cy_self_ = 0.0;
        int width_self_ = 0, height_self_ = 0;

        double fx_other_ = 480.0, fy_other_ = 479.695;
        double cx_other_ = 480.5, cy_other_ = 270.5;
        int width_other_ = 960, height_other_ = 540;

        // ===== 盲区 =====
        cv::Point2d left_top_blind_;
        cv::Point2d right_bottom_blind_;

        // ===== patch 参数 =====
        int patch_cols_ = 0;
        int patch_rows_ = 0;
        double deg_thresh_ = 0.0;

        // ===== 激光雷达通道角度 =====
        double channel_angles_[32];

        // ===== 状态标志 =====
        bool intrinsic_self_ready_ = false;
        bool intrinsic_other_ready_ = false;
        bool extrinsic_other_ready_ = false;

        // ===== 历史队列（用于时间匹配） =====
        std::deque<sensor_msgs::msg::Image::ConstSharedPtr> image_a_history_;
        std::deque<sensor_msgs::msg::Image::ConstSharedPtr> image_b_history_;
        std::deque<geometry_msgs::msg::PoseStamped::ConstSharedPtr> pose_a_history_;
        std::deque<geometry_msgs::msg::PoseStamped::ConstSharedPtr> pose_b_history_;
        std::mutex data_mutex_;                     // 保护历史队列

        // ===== ROS 订阅器 =====
        rclcpp::Subscription<sensor_msgs::msg::CameraInfo>::SharedPtr info_self_sub_;
        rclcpp::Subscription<sensor_msgs::msg::CameraInfo>::SharedPtr info_other_sub_;
        rclcpp::Subscription<geometry_msgs::msg::Transform>::SharedPtr extrinsic_other_sub_;

        rclcpp::Subscription<sensor_msgs::msg::Image>::SharedPtr image_self_sub_;      // image_a
        rclcpp::Subscription<sensor_msgs::msg::Image>::SharedPtr image_b_sub_;         // another_image
        rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr pose_self_sub_; // pose_a
        rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr pose_other_sub_; // pose_b
        rclcpp::Subscription<sensor_msgs::msg::PointCloud2>::SharedPtr cloud_b_sub_;    // 点云（主触发）

        // ===== 发布器 =====
        image_transport::Publisher result_pub_;
        image_transport::Publisher another_processed_pub_;   // 新增：用于发布单独处理的他车图像
    };

} // namespace self_vehicle

#endif // SELF_VEHICLE_HPP