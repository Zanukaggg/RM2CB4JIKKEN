from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='traffic_light_image',
            executable='traffic_light_binary',
            name='traffic_light_binary',
            output='screen',
            parameters=[{
                # topic
                'in_topic': '/sensing/camera/traffic_light/image_raw',
                'out_topic': '/sensing/camera/traffic_light/image_binary',

                # performance
                'scale': 0.5,          # 建议 0.25 ~ 0.5
                'threshold': 120,      # 二值阈值

                # ROI: [x1, y1, x2, y2]，不用就注释掉或删除
                # 'roi': [400, 200, 1000, 800],
            }]
        )
    ])

