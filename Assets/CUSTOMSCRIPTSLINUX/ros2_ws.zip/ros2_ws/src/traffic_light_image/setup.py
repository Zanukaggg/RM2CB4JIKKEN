from setuptools import setup, find_packages

package_name = 'traffic_light_image'

setup(
    name=package_name,
    version='0.0.1',

    # ✅ 自动找到 traffic_light_image 及其所有子模块
    packages=find_packages(),

    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/traffic_light_binary.launch.py']),
    ],

    install_requires=['setuptools'],
    zip_safe=True,

    maintainer='user',
    maintainer_email='user@example.com',
    description='Downscale + high-impact image processing for traffic light camera',
    license='Apache License 2.0',

    entry_points={
        'console_scripts': [
            'traffic_light_binary = traffic_light_image.traffic_light_binary_node:main',
        ],
    },
)

