#!/usr/bin/env python3
"""
traffic_light_binary_node.py  （低延迟展示版）

优化点：
  1. 回调一开始立刻 resize（大幅降低数据量）
  2. 节流处理频率（避免 CPU / RViz2 被压爆）
  3. QoS 对齐 AWSIM（Best Effort）

订阅：
  /sensing/camera/traffic_light/image_raw

发布：
  /sensing/camera/traffic_light/image_binary
"""

import time
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy

from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2

# 图像处理模块
from traffic_light_image.image_processor import ImageProcessor


class TrafficLightBinaryNode(Node):
    def __init__(self):
        super().__init__('traffic_light_binary')

        # ===============================
        # topic
        # ===============================
        self.in_topic = '/sensing/camera/traffic_light/image_raw'
        self.out_topic = '/sensing/camera/traffic_light/image_binary'

        # ===============================
        # QoS（严格匹配 AWSIM）
        # ===============================
        self.qos_image = QoSProfile(
            depth=5,
            history=HistoryPolicy.KEEP_LAST,
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE
        )

        # ===============================
        # ROS 接口
        # ===============================
        self.bridge = CvBridge()

        self.sub = self.create_subscription(
            Image,
            self.in_topic,
            self.image_callback,
            self.qos_image
        )

        self.pub = self.create_publisher(
            Image,
            self.out_topic,
            self.qos_image
        )

        # ===============================
        # 图像处理器（视觉冲击版）
        # ===============================
        self.processor = ImageProcessor(
            alpha=2.0,      # 对比度
            beta=60,        # 曝光
            sat_gain=1.8,
            val_gain=1.4
        )

        # ===============================
        # 【优化点 1】降分辨率比例
        # ===============================
        self.resize_scale = 0.5   # 直接砍到 1/16 像素量

        # ===============================
        # 【优化点 2】节流（Hz）
        # ===============================
        self.min_period = 0.2      # 5 Hz
        self.last_time = 0.0

        # ===============================
        # log
        # ===============================
        self.get_logger().info('traffic_light_binary (LOW LATENCY MODE)')
        self.get_logger().info(f'  resize_scale: {self.resize_scale}')
        self.get_logger().info(f'  publish_rate: {1.0 / self.min_period:.1f} Hz')
        self.get_logger().info(f'  in_topic:  {self.in_topic}')
        self.get_logger().info(f'  out_topic: {self.out_topic}')

    def image_callback(self, msg: Image):
        # ===============================
        # 【节流】先判断时间
        # ===============================
        now = time.time()
        if now - self.last_time < self.min_period:
            return
        self.last_time = now

        # ===============================
        # ROS → OpenCV
        # ===============================
        try:
            cv_image = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
        except Exception as e:
            self.get_logger().warn(f'cv_bridge failed: {e}')
            return

        # ===============================
        # 【关键优化】第一时间 resize
        # ===============================
        cv_image = cv2.resize(
            cv_image,
            None,
            fx=self.resize_scale,
            fy=self.resize_scale,
            interpolation=cv2.INTER_AREA
        )

        # ===============================
        # 图像处理（高曝光 + 强视觉）
        # ===============================
        try:
            processed = self.processor.process(cv_image)
        except Exception as e:
            self.get_logger().warn(f'processing failed: {e}')
            return

        # ===============================
        # OpenCV → ROS
        # ===============================
        try:
            out_msg = self.bridge.cv2_to_imgmsg(processed, encoding='bgr8')
            out_msg.header = msg.header
            self.pub.publish(out_msg)
        except Exception as e:
            self.get_logger().warn(f'publish failed: {e}')


def main():
    rclpy.init()
    node = TrafficLightBinaryNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

