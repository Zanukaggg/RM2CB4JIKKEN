#!/usr/bin/env python3
"""
image_processor.py

展示用图像处理模块（方案 1）：
  - 高曝光拉伸
  - HSV 空间增强（高饱和 + 高亮）
  - 强视觉冲击力，适合演示

输入：
  - OpenCV BGR 图像（uint8）

输出：
  - OpenCV BGR 图像（uint8）
"""

import cv2
import numpy as np


class ImageProcessor:
    def __init__(
        self,
        alpha: float = 2.0,   # 对比度增益（>1 提升对比）
        beta: int = 60,       # 亮度偏移（曝光）
        sat_gain: float = 1.8,  # 饱和度增益
        val_gain: float = 1.4   # 亮度通道增益
    ):
        self.alpha = alpha
        self.beta = beta
        self.sat_gain = sat_gain
        self.val_gain = val_gain

    def process(self, bgr_img: np.ndarray) -> np.ndarray:
        """
        主处理函数
        """

        if bgr_img is None or bgr_img.size == 0:
            raise ValueError("Empty image received")

        # ===============================
        # 1. 高曝光拉伸（亮度 + 对比度）
        # ===============================
        exposed = cv2.convertScaleAbs(
            bgr_img,
            alpha=self.alpha,
            beta=self.beta
        )

        # ===============================
        # 2. BGR → HSV
        # ===============================
        hsv = cv2.cvtColor(exposed, cv2.COLOR_BGR2HSV)

        h, s, v = cv2.split(hsv)

        # ===============================
        # 3. HSV 增强
        # ===============================
        s = np.clip(s.astype(np.float32) * self.sat_gain, 0, 255).astype(np.uint8)
        v = np.clip(v.astype(np.float32) * self.val_gain, 0, 255).astype(np.uint8)

        hsv_enhanced = cv2.merge([h, s, v])

        # ===============================
        # 4. HSV → BGR
        # ===============================
        result = cv2.cvtColor(hsv_enhanced, cv2.COLOR_HSV2BGR)

        return result

