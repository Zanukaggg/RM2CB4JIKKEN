#!/usr/bin/env bash

set -e

# 进入工作空间
cd "$(dirname "$0")"

# 构建（如果已经构建过，几秒就结束）
colcon build

# 加载环境
source install/setup.bash

# 启动节点
ros2 launch traffic_light_image traffic_light_binary.launch.py

