#ifndef ANOTHER_VEHICLE_HPP
#define ANOTHER_VEHICLE_HPP

#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <sensor_msgs/msg/image.hpp>
#include <sensor_msgs/msg/camera_info.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <geometry_msgs/msg/transform.hpp>
#include <std_msgs/msg/int16_multi_array.hpp>
#include <image_transport/image_transport.hpp>
#include <cv_bridge/cv_bridge.h>
#include <Eigen/Dense>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include <vector>
#include <memory>
#include <string>
#include <cmath>
#include <mutex>
#include <deque>

#include <message_filters/subscriber.h>
#include <message_filters/synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>

namespace another_vehicle
{

    class AnotherVehicleNode : public rclcpp::Node
    {
    public:
        AnotherVehicleNode();

    private:
        void info_callback(const sensor_msgs::msg::CameraInfo::SharedPtr msg);
        void image_callback(const sensor_msgs::msg::Image::ConstSharedPtr msg);
        void pose_callback(const geometry_msgs::msg::PoseStamped::SharedPtr msg);
        void points_callback(const sensor_msgs::msg::PointCloud2::SharedPtr msg);
        void extrinsic_callback(const geometry_msgs::msg::Transform::SharedPtr msg);

        bool getPoseAtTime(const rclcpp::Time& stamp,
            geometry_msgs::msg::PoseStamped& out_pose) const;

        bool getClosestImage(const rclcpp::Time& stamp,
            sensor_msgs::msg::Image::ConstSharedPtr& out_img,
            double max_diff);

        void synced_callback(
            const sensor_msgs::msg::PointCloud2::SharedPtr cloud,
            const sensor_msgs::msg::Image::SharedPtr image);

        bool projection_flag_ = false;
        bool intrinsic_flag_ = false;
        bool pose_flag_ = false;
        bool image_flag_ = false;

        mutable std::mutex extrinsic_mutex_;
        Eigen::Matrix3d R_LC_;
        Eigen::Vector3d t_LC_;
        double inv_rt_LC_[3];

        mutable std::mutex pose_mutex_;
        std::deque<geometry_msgs::msg::PoseStamped> pose_history_;
        static constexpr size_t MAX_POSE_HISTORY = 300;

        double orientation_WL_[4];
        double rotation_WL_[9];
        double transform_WL_[3];

        double fx_ = 0.0, fy_ = 0.0, cx_ = 0.0, cy_ = 0.0;
        int width_ = 0, height_ = 0;
        double max_tan_;

        double vert_angle_[32];

        sensor_msgs::msg::Image::ConstSharedPtr last_image_;
        std::deque<sensor_msgs::msg::Image::ConstSharedPtr> image_buffer_;

        std::mutex last_image_mutex_;
        std::mutex image_mutex_;

        mutable std::mutex image_history_mutex_;
        std::deque<sensor_msgs::msg::Image::ConstSharedPtr> image_history_;
        double sync_max_time_diff_;

        sensor_msgs::msg::PointCloud2 another_cloud_;

        double transform_x_, transform_y_, transform_z_;
        double roll_offset_, pitch_offset_, yaw_offset_;
        double max_range_;
        double phi_left_, phi_right_;

        int frame_count_ = 0;

        rclcpp::Subscription<sensor_msgs::msg::PointCloud2>::SharedPtr points_sub_;
        rclcpp::Subscription<sensor_msgs::msg::CameraInfo>::SharedPtr info_sub_;
        rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr pose_sub_;
        rclcpp::Subscription<geometry_msgs::msg::Transform>::SharedPtr extrinsic_sub_;
        image_transport::Subscriber image_sub_;

        rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr cloud_pub_;
        image_transport::Publisher image_pub_;
        rclcpp::Publisher<geometry_msgs::msg::PoseStamped>::SharedPtr pose_pub_;
        rclcpp::Publisher<geometry_msgs::msg::Transform>::SharedPtr extrinsic_pub_;
        rclcpp::Publisher<sensor_msgs::msg::CameraInfo>::SharedPtr intrinsic_pub_;
        rclcpp::Publisher<std_msgs::msg::Int16MultiArray>::SharedPtr ring_count_pub_;

        using MySyncPolicy = message_filters::sync_policies::ApproximateTime<
            sensor_msgs::msg::PointCloud2,
            sensor_msgs::msg::Image
        >;

        std::shared_ptr<message_filters::Subscriber<sensor_msgs::msg::PointCloud2>> cloud_sub_;
        std::shared_ptr<message_filters::Subscriber<sensor_msgs::msg::Image>> image_sub_sync_;
        std::shared_ptr<message_filters::Synchronizer<MySyncPolicy>> sync_;

        // 优化新增成员：复用缓冲区
        std::vector<float> buf_;
        // 缓存点云字段偏移
        int off_x_ = -1, off_y_ = -1, off_z_ = -1;
    };

} // namespace another_vehicle

#endif // ANOTHER_VEHICLE_HPP