#include "self_vehicle.hpp"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <deque>
#include <map>
#include <mutex>
#include <sstream>
#include <string>
#include <vector>
#include <unordered_map>

#include <cv_bridge/cv_bridge.h>
#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/opencv.hpp>
#include <rclcpp/qos.hpp>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>

namespace self_vehicle
{

// ================= 用户可调参数（手动修改） =================

static constexpr bool ENABLE_SEGMENT_FILL = true;   // 线段纹理粘贴（盲区填补）
static constexpr bool ENABLE_RECT_COPY = true;      // 矩形拷贝（累积混合模式）
static constexpr bool ENABLE_DEPTH_DEFORMATION = true; // 深度变形（他车图像）

// 是否发布 /another_image_processed（深度变形后的他车图像）
static constexpr bool ENABLE_ANOTHER_PROCESSED_PUB = false;

// 图像锐化参数（用于 /localize_image_prime）
static constexpr bool ENABLE_SHARPEN = true;        // 启用锐化
static constexpr double SHARPEN_SIGMA = 1.0;        // 高斯模糊 sigma
static constexpr double SHARPEN_AMOUNT = 1.0;       // 锐化强度（0.5~1.5）
static constexpr double SHARPEN_THRESHOLD = 0.0;    // 亮度变化阈值（0 表示全图）

static constexpr bool DEBUG_GREEN_PATCH = false;    // 真实纹理模式

// 深度变形参数
static constexpr double MIN_DEPTH_FOR_SCALE = 1.0;
static constexpr double MAX_DEPTH_FOR_SCALE = 30.0;
static constexpr int DEPTH_RADIUS = 15;
static constexpr int GAUSS_KERNEL = 31;
static constexpr double GAUSS_SIGMA = 10.0;
static constexpr double MIN_SCALE = 0.6;
static constexpr double MAX_SCALE = 2.0;

// 点云坐标平移
static constexpr double POINT_CLOUD_SHIFT_U = -38;
static constexpr double POINT_CLOUD_SHIFT_V = 0;

// 动态 ROI 参数
static constexpr bool DYNAMIC_ROI_ENABLED = true;
static constexpr int ROI_EXPAND_HORIZONTAL = 400;
static constexpr int ROI_EXPAND_VERTICAL = 60;
static constexpr int ROI_SHIFT_U = -25;
static constexpr int ROI_SHIFT_V = 65;
static constexpr bool DRAW_ROI_RECT = true;

// 盲区矩形
static constexpr double BLIND_LEFT_TOP_X = 500.0;
static constexpr double BLIND_LEFT_TOP_Y = 400.0;
static constexpr double BLIND_RIGHT_BOTTOM_X = 600.0;
static constexpr double BLIND_RIGHT_BOTTOM_Y = 500.0;

// 纹理 patch 基础大小
static constexpr int BASE_PATCH_COLS = 15;
static constexpr int BASE_PATCH_ROWS = 15;
static constexpr double DEG_THRESH = 5.0;

// 深度自适应缩放参数
static constexpr double DEPTH_SCALE_REF = 10.0;
static constexpr double MIN_DEPTH_SCALE = 0.5;
static constexpr double MAX_DEPTH_SCALE = 2.0;

// 密度自适应缩放参数
static constexpr double DENSITY_RADIUS = 30.0;
static constexpr double BASE_DENSITY = 5.0;
static constexpr double MIN_DENSITY_SCALE = 0.4;
static constexpr double MAX_DENSITY_SCALE = 1.5;

// 最终矩形尺寸限制
static constexpr int MIN_RECT_SIZE = 5;
static constexpr int MAX_RECT_SIZE = 40;

// 高斯权重 sigma 因子
static constexpr double GAUSS_SIGMA_FACTOR = 0.3;

// 稀疏区域插值参数
static constexpr double SPARSE_DIST_THRESH = 30.0;
static constexpr int MAX_INTERP_POINTS = 5;

// 画布参数（用于 /localize_image_prime）
static constexpr int CANVAS_WIDTH = 1920;
static constexpr int CANVAS_HEIGHT = 1080;

// 自车外参
static constexpr double SELF_TRANSFORM_X = -0.1;
static constexpr double SELF_TRANSFORM_Y = -0.05;
static constexpr double SELF_TRANSFORM_Z = 0.0175;
static constexpr double SELF_ROLL_OFFSET = -90.0;
static constexpr double SELF_PITCH_OFFSET = 0.0;
static constexpr double SELF_YAW_OFFSET = 0.0;

// 他车外参
static constexpr double ANOTHER_TRANSFORM_X = -0.1;
static constexpr double ANOTHER_TRANSFORM_Y = -0.05;
static constexpr double ANOTHER_TRANSFORM_Z = 0.0175;
static constexpr double ANOTHER_ROLL_OFFSET = -90.0;
static constexpr double ANOTHER_PITCH_OFFSET = 0.0;
static constexpr double ANOTHER_YAW_OFFSET = 0.0;

// ========================================================

static constexpr double SYNC_MAX_TIME_DIFF = 0.1;
static constexpr double EPS = 1e-6;
static constexpr size_t MAX_HISTORY = 200;

namespace {
    // 他车外参（静态，只初始化一次）
    Eigen::Matrix3d g_R_LC_other;
    Eigen::Vector3d g_t_LC_other;
    bool g_other_extrinsic_initialized = false;
    std::mutex g_other_extrinsic_mutex;
}

static std::string mat3ToString(const Eigen::Matrix3d& m) {
    std::ostringstream oss;
    oss.setf(std::ios::fixed);
    oss.precision(6);
    oss << "[" << m(0,0) << ", " << m(0,1) << ", " << m(0,2) << "; "
        << m(1,0) << ", " << m(1,1) << ", " << m(1,2) << "; "
        << m(2,0) << ", " << m(2,1) << ", " << m(2,2) << "]";
    return oss.str();
}

static std::string vec3ToString(const Eigen::Vector3d& v) {
    std::ostringstream oss;
    oss.setf(std::ios::fixed);
    oss.precision(6);
    oss << "(" << v.x() << ", " << v.y() << ", " << v.z() << ")";
    return oss.str();
}

template<typename T>
static bool getClosest(const std::deque<T>& queue, const rclcpp::Time& stamp,
                       T& out, double max_diff, bool& exact) {
    if (queue.empty()) return false;
    T best = queue.front();
    double best_diff = std::abs((rclcpp::Time(best->header.stamp) - stamp).seconds());
    for (const auto& item : queue) {
        double diff = std::abs((rclcpp::Time(item->header.stamp) - stamp).seconds());
        if (diff < best_diff) { best_diff = diff; best = item; }
    }
    exact = (best_diff <= max_diff);
    out = best;
    return true;
}

SelfVehicleNode::SelfVehicleNode() : Node("self_vehicle") {
    // 自车外参
    const double tx_s = SELF_TRANSFORM_X, ty_s = SELF_TRANSFORM_Y, tz_s = SELF_TRANSFORM_Z;
    const double roll_s = SELF_ROLL_OFFSET * M_PI / 180.0;
    const double pitch_s = SELF_PITCH_OFFSET * M_PI / 180.0;
    const double yaw_s = SELF_YAW_OFFSET * M_PI / 180.0;

    // 他车外参
    const double tx_a = ANOTHER_TRANSFORM_X, ty_a = ANOTHER_TRANSFORM_Y, tz_a = ANOTHER_TRANSFORM_Z;
    const double roll_a = ANOTHER_ROLL_OFFSET * M_PI / 180.0;
    const double pitch_a = ANOTHER_PITCH_OFFSET * M_PI / 180.0;
    const double yaw_a = ANOTHER_YAW_OFFSET * M_PI / 180.0;

    patch_cols_ = BASE_PATCH_COLS;
    patch_rows_ = BASE_PATCH_ROWS;
    deg_thresh_ = DEG_THRESH;

    left_top_blind_.x = BLIND_LEFT_TOP_X;
    left_top_blind_.y = BLIND_LEFT_TOP_Y;
    right_bottom_blind_.x = BLIND_RIGHT_BOTTOM_X;
    right_bottom_blind_.y = BLIND_RIGHT_BOTTOM_Y;

    // 自车外参矩阵
    Eigen::Matrix3d R_roll_s, R_pitch_s, R_yaw_s;
    R_roll_s << 1,0,0, 0,cos(roll_s),-sin(roll_s), 0,sin(roll_s),cos(roll_s);
    R_pitch_s << cos(pitch_s),0,sin(pitch_s), 0,1,0, -sin(pitch_s),0,cos(pitch_s);
    R_yaw_s << cos(yaw_s),-sin(yaw_s),0, sin(yaw_s),cos(yaw_s),0, 0,0,1;
    Eigen::Matrix3d R_base; R_base << 1,0,0, 0,0,1, 0,-1,0;
    R_LC_self_ = R_yaw_s * R_pitch_s * R_roll_s * R_base;
    t_LC_self_ << tx_s, ty_s, tz_s;

    // 他车外参矩阵
    Eigen::Matrix3d R_roll_a, R_pitch_a, R_yaw_a;
    R_roll_a << 1,0,0, 0,cos(roll_a),-sin(roll_a), 0,sin(roll_a),cos(roll_a);
    R_pitch_a << cos(pitch_a),0,sin(pitch_a), 0,1,0, -sin(pitch_a),0,cos(pitch_a);
    R_yaw_a << cos(yaw_a),-sin(yaw_a),0, sin(yaw_a),cos(yaw_a),0, 0,0,1;
    {
        std::lock_guard<std::mutex> lock(g_other_extrinsic_mutex);
        g_R_LC_other = R_yaw_a * R_pitch_a * R_roll_a * R_base;
        g_t_LC_other << tx_a, ty_a, tz_a;
        g_other_extrinsic_initialized = true;
    }

    RCLCPP_INFO(this->get_logger(), "Self extrinsic matrix = %s", mat3ToString(R_LC_self_).c_str());
    RCLCPP_INFO(this->get_logger(), "Self extrinsic t = %s", vec3ToString(t_LC_self_).c_str());
    RCLCPP_INFO(this->get_logger(), "Other extrinsic matrix = %s", mat3ToString(g_R_LC_other).c_str());
    RCLCPP_INFO(this->get_logger(), "Other extrinsic t = %s", vec3ToString(g_t_LC_other).c_str());

    // 订阅器
    info_self_sub_ = this->create_subscription<sensor_msgs::msg::CameraInfo>(
        "/sensing/camera/traffic_light/camera_info", rclcpp::SensorDataQoS(),
        std::bind(&SelfVehicleNode::info_self_callback, this, std::placeholders::_1));
    auto qos_transient = rclcpp::QoS(1).transient_local();
    info_other_sub_ = this->create_subscription<sensor_msgs::msg::CameraInfo>(
        "/another_intrinsic", qos_transient,
        std::bind(&SelfVehicleNode::info_other_callback, this, std::placeholders::_1));
    image_self_sub_ = this->create_subscription<sensor_msgs::msg::Image>(
        "/sensing/camera/traffic_light/image_raw", rclcpp::SensorDataQoS(),
        std::bind(&SelfVehicleNode::image_a_callback, this, std::placeholders::_1));
    image_b_sub_ = this->create_subscription<sensor_msgs::msg::Image>(
        "/another_image", rclcpp::SensorDataQoS(),
        std::bind(&SelfVehicleNode::image_b_callback, this, std::placeholders::_1));
    pose_self_sub_ = this->create_subscription<geometry_msgs::msg::PoseStamped>(
        "/sensing/gnss/pose", rclcpp::SensorDataQoS(),
        std::bind(&SelfVehicleNode::pose_a_callback, this, std::placeholders::_1));
    pose_other_sub_ = this->create_subscription<geometry_msgs::msg::PoseStamped>(
        "/another_pose", rclcpp::SensorDataQoS(),
        std::bind(&SelfVehicleNode::pose_b_callback, this, std::placeholders::_1));
    cloud_b_sub_ = this->create_subscription<sensor_msgs::msg::PointCloud2>(
        "/another_cloud", rclcpp::SensorDataQoS(),
        std::bind(&SelfVehicleNode::points_callback, this, std::placeholders::_1));
    result_pub_ = image_transport::create_publisher(this, "/localize_image");
    another_processed_pub_ = image_transport::create_publisher(this, "/another_image_processed");
    canvas_pub_ = this->create_publisher<sensor_msgs::msg::Image>("/localize_image_prime", 10);
}

// ---------- 内参回调 ----------
void SelfVehicleNode::info_self_callback(const sensor_msgs::msg::CameraInfo::SharedPtr msg) {
    fx_self_ = msg->k[0]; fy_self_ = msg->k[4]; cx_self_ = msg->k[2]; cy_self_ = msg->k[5];
    width_self_ = msg->width; height_self_ = msg->height;
    selfD_count_ = 0;
    std::fill(std::begin(dist_coeff_self_), std::end(dist_coeff_self_), 0.0);
    for (size_t i = 0; i < msg->d.size() && i < 8; ++i) {
        dist_coeff_self_[i] = msg->d[i];
        if (msg->d[i] != 0.0) ++selfD_count_;
    }
    intrinsic_self_ready_ = true;
}

void SelfVehicleNode::info_other_callback(const sensor_msgs::msg::CameraInfo::SharedPtr msg) {
    fx_other_ = msg->k[0]; fy_other_ = msg->k[4]; cx_other_ = msg->k[2]; cy_other_ = msg->k[5];
    width_other_ = msg->width; height_other_ = msg->height;
    otherD_count_ = 0;
    std::fill(std::begin(dist_coeff_other_), std::end(dist_coeff_other_), 0.0);
    for (size_t i = 0; i < msg->d.size() && i < 8; ++i) {
        dist_coeff_other_[i] = msg->d[i];
        if (msg->d[i] != 0.0) ++otherD_count_;
    }
    intrinsic_other_ready_ = true;
}

// ---------- 图像 / 位姿 缓存 ----------
void SelfVehicleNode::image_a_callback(const sensor_msgs::msg::Image::ConstSharedPtr msg) {
    std::lock_guard<std::mutex> lock(data_mutex_);
    image_a_history_.push_back(msg);
    if (image_a_history_.size() > MAX_HISTORY) image_a_history_.pop_front();
}
void SelfVehicleNode::image_b_callback(const sensor_msgs::msg::Image::ConstSharedPtr msg) {
    std::lock_guard<std::mutex> lock(data_mutex_);
    image_b_history_.push_back(msg);
    if (image_b_history_.size() > MAX_HISTORY) image_b_history_.pop_front();
}
void SelfVehicleNode::pose_a_callback(const geometry_msgs::msg::PoseStamped::ConstSharedPtr msg) {
    auto corrected = std::make_shared<geometry_msgs::msg::PoseStamped>(*msg);
    if (corrected->pose.orientation.x == 0.0 && corrected->pose.orientation.y == 0.0 &&
        corrected->pose.orientation.z == 0.0 && corrected->pose.orientation.w == 0.0) {
        corrected->pose.orientation.w = 1.0;
    }
    std::lock_guard<std::mutex> lock(data_mutex_);
    pose_a_history_.push_back(corrected);
    if (pose_a_history_.size() > MAX_HISTORY) pose_a_history_.pop_front();
}
void SelfVehicleNode::pose_b_callback(const geometry_msgs::msg::PoseStamped::ConstSharedPtr msg) {
    auto corrected = std::make_shared<geometry_msgs::msg::PoseStamped>(*msg);
    if (corrected->pose.orientation.x == 0.0 && corrected->pose.orientation.y == 0.0 &&
        corrected->pose.orientation.z == 0.0 && corrected->pose.orientation.w == 0.0) {
        corrected->pose.orientation.w = 1.0;
    }
    std::lock_guard<std::mutex> lock(data_mutex_);
    pose_b_history_.push_back(corrected);
    if (pose_b_history_.size() > MAX_HISTORY) pose_b_history_.pop_front();
}

// ---------- 辅助函数 ----------
Eigen::Matrix3d SelfVehicleNode::quat_to_matrix(const geometry_msgs::msg::Quaternion& q) {
    const double norm_sq = q.x*q.x + q.y*q.y + q.z*q.z + q.w*q.w;
    if (norm_sq < EPS) {
        RCLCPP_WARN(this->get_logger(), "Zero quaternion detected, using identity.");
        return Eigen::Matrix3d::Identity();
    }
    tf2::Quaternion tf_q(q.x, q.y, q.z, q.w);
    tf2::Matrix3x3 tf_m(tf_q);
    Eigen::Matrix3d m;
    for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) m(i,j) = tf_m[i][j];
    return m;
}
bool SelfVehicleNode::in_image(double u, double v, int w, int h) const {
    return u >= 0 && u < w && v >= 0 && v < h;
}
int SelfVehicleNode::region_judge(const cv::Point2d& a, const cv::Point2d& b,
    const cv::Point2d& left_top, const cv::Point2d& right_bottom) {
    bool a_in = (left_top.x - EPS < a.x && a.x < right_bottom.x + EPS &&
                 left_top.y - EPS < a.y && a.y < right_bottom.y + EPS);
    bool b_in = (left_top.x - EPS < b.x && b.x < right_bottom.x + EPS &&
                 left_top.y - EPS < b.y && b.y < right_bottom.y + EPS);
    if (!a_in && !b_in) return 0;
    if (a_in && !b_in) return 1;
    if (!a_in && b_in) return 2;
    return 3;
}
bool SelfVehicleNode::intersection_judge(const cv::Point2d& a, const cv::Point2d& b,
    const cv::Point2d& c, const cv::Point2d& d) {
    if (std::min(a.x,b.x) > std::max(c.x,d.x) || std::min(c.x,d.x) > std::max(a.x,b.x) ||
        std::min(a.y,b.y) > std::max(c.y,d.y) || std::min(c.y,d.y) > std::max(a.y,b.y))
        return false;
    auto cross = [](const cv::Point2d& o, const cv::Point2d& p, const cv::Point2d& q) {
        return (p.x - o.x)*(q.y - o.y) - (p.y - o.y)*(q.x - o.x);
    };
    double d1 = cross(a,b,c), d2 = cross(a,b,d), d3 = cross(c,d,a), d4 = cross(c,d,b);
    return (d1*d2 < 0 && d3*d4 < 0);
}
cv::Point2d SelfVehicleNode::intersection(const cv::Point2d& a, const cv::Point2d& b,
    const cv::Point2d& c, const cv::Point2d& d) {
    cv::Point2d v1 = b - a, v2 = d - c;
    double det = v1.x*v2.y - v1.y*v2.x;
    if (std::abs(det) < EPS) return cv::Point2d(-1,-1);
    double t = ((c.x - a.x)*v2.y - (c.y - a.y)*v2.x) / det;
    double u = ((c.x - a.x)*v1.y - (c.y - a.y)*v1.x) / det;
    if (t >= 0 && t <= 1 && u >= 0 && u <= 1) return a + t * v1;
    return cv::Point2d(-1,-1);
}
cv::Point2d SelfVehicleNode::intersection_region(const cv::Point2d& p1, const cv::Point2d& p2,
    const cv::Point2d region_pts[4]) {
    for (int i = 0; i < 4; ++i) {
        if (intersection_judge(p1, p2, region_pts[i], region_pts[(i+1)%4]))
            return intersection(p1, p2, region_pts[i], region_pts[(i+1)%4]);
    }
    return cv::Point2d(-1,-1);
}
void SelfVehicleNode::intersection_region_2pts(const cv::Point2d& p1, const cv::Point2d& p2,
    const cv::Point2d region_pts[4], cv::Point2d result[2], double ratio[2]) {
    int cnt = 0;
    result[0] = cv::Point2d(-1,-1); result[1] = cv::Point2d(-1,-1);
    double dist_p1p2 = cv::norm(p1-p2);
    if (dist_p1p2 < EPS) return;
    for (int i = 0; i < 4 && cnt < 2; ++i) {
        if (intersection_judge(p1, p2, region_pts[i], region_pts[(i+1)%4])) {
            cv::Point2d inter = intersection(p1, p2, region_pts[i], region_pts[(i+1)%4]);
            if (inter.x < 0) continue;
            if (cnt == 0) {
                result[0] = inter;
                ratio[0] = cv::norm(inter - p1) / dist_p1p2;
                cnt++;
            } else {
                result[1] = inter;
                ratio[1] = cv::norm(inter - p1) / dist_p1p2;
                cnt++;
            }
        }
    }
    if (cnt == 2 && ratio[0] > ratio[1]) {
        std::swap(result[0], result[1]);
        std::swap(ratio[0], ratio[1]);
    }
}
void SelfVehicleNode::parse_pointcloud(const sensor_msgs::msg::PointCloud2::ConstSharedPtr& cloud,
    std::map<uint16_t, std::vector<PointData>>& out_map) {
    int off_x=-1, off_y=-1, off_z=-1, off_ch=-1;
    uint8_t ch_datatype=0;
    bool has_channel=false;
    for (const auto& f : cloud->fields) {
        if (f.name=="x") off_x=f.offset;
        else if (f.name=="y") off_y=f.offset;
        else if (f.name=="z") off_z=f.offset;
        else if (f.name=="channel") { off_ch=f.offset; ch_datatype=f.datatype; has_channel=true; }
    }
    if (off_x<0 || off_y<0 || off_z<0) { RCLCPP_ERROR(this->get_logger(), "Missing x,y,z fields."); return; }
    const uint8_t* data = cloud->data.data();
    const size_t point_count = cloud->width * cloud->height;
    for (size_t i = 0; i < point_count; ++i) {
        const uint8_t* ptr = data + i * cloud->point_step;
        float x,y,z; std::memcpy(&x, ptr+off_x, sizeof(float)); std::memcpy(&y, ptr+off_y, sizeof(float)); std::memcpy(&z, ptr+off_z, sizeof(float));
        if (!std::isfinite(x)||!std::isfinite(y)||!std::isfinite(z)) continue;
        uint16_t ch=0;
        if (has_channel && off_ch>=0) {
            switch (ch_datatype) {
                case sensor_msgs::msg::PointField::UINT16: { uint16_t tmp; std::memcpy(&tmp, ptr+off_ch, sizeof(uint16_t)); ch=tmp; break; }
                case sensor_msgs::msg::PointField::UINT32: { uint32_t tmp; std::memcpy(&tmp, ptr+off_ch, sizeof(uint32_t)); ch=static_cast<uint16_t>(tmp); break; }
                case sensor_msgs::msg::PointField::UINT8: { uint8_t tmp; std::memcpy(&tmp, ptr+off_ch, sizeof(uint8_t)); ch=tmp; break; }
                case sensor_msgs::msg::PointField::FLOAT32: { float tmp; std::memcpy(&tmp, ptr+off_ch, sizeof(float)); if(std::isfinite(tmp) && tmp>=0) ch=static_cast<uint16_t>(tmp); break; }
                default: ch=0;
            }
        }
        PointData p; p.x=x; p.y=y; p.z=z; p.azimuth=std::atan2(y,x);
        p.u_a=p.v_a=p.u_b=p.v_b=0; p.depth_self=0.0; p.channel=ch; p.valid=false;
        out_map[ch].push_back(p);
    }
}
static void applyDistortion(double x, double y, const double* dist, int dcount, double& xd, double& yd) {
    if (dcount < 5) { xd=x; yd=y; return; }
    double r2 = x*x + y*y, r4 = r2*r2, r6 = r4*r2;
    double radial = 1 + dist[0]*r2 + dist[1]*r4 + dist[4]*r6;
    if (dcount >= 8) {
        double denom = 1 + dist[5]*r2 + dist[6]*r4 + dist[7]*r6;
        if (std::abs(denom) > 1e-12) radial /= denom;
    }
    xd = x*radial + 2*dist[2]*x*y + dist[3]*(r2+2*x*x);
    yd = y*radial + dist[2]*(r2+2*y*y) + 2*dist[3]*x*y;
}
static inline double getDepthScale(double depth) {
    double scale = DEPTH_SCALE_REF / depth;
    return std::min(MAX_DEPTH_SCALE, std::max(MIN_DEPTH_SCALE, scale));
}
static inline double getGaussianWeight(double dist2, double sigma2) {
    return std::exp(-dist2 / (2.0 * sigma2));
}

// 统计每个点的局部密度（自车图像上周围半径内的邻居数量），使用网格加速
static std::vector<int> computeDensities(const std::vector<PointData>& points, double radius, int img_w, int img_h) {
    const int grid_cell = 50;
    int grid_cols = (img_w + grid_cell - 1) / grid_cell;
    int grid_rows = (img_h + grid_cell - 1) / grid_cell;
    std::vector<std::vector<std::pair<int,int>>> grid(grid_rows * grid_cols); // (u, v)
    for (size_t i = 0; i < points.size(); ++i) {
        int u = static_cast<int>(points[i].u_a);
        int v = static_cast<int>(points[i].v_a);
        if (u < 0 || u >= img_w || v < 0 || v >= img_h) continue;
        int gx = u / grid_cell, gy = v / grid_cell;
        if (gx >= 0 && gx < grid_cols && gy >= 0 && gy < grid_rows) {
            grid[gy * grid_cols + gx].emplace_back(u, v);
        }
    }
    std::vector<int> densities(points.size(), 0);
    int radius_int = static_cast<int>(std::ceil(radius));
    for (size_t i = 0; i < points.size(); ++i) {
        int u = static_cast<int>(points[i].u_a);
        int v = static_cast<int>(points[i].v_a);
        if (u < 0 || u >= img_w || v < 0 || v >= img_h) continue;
        int gx0 = (u - radius_int) / grid_cell, gx1 = (u + radius_int) / grid_cell;
        int gy0 = (v - radius_int) / grid_cell, gy1 = (v + radius_int) / grid_cell;
        gx0 = std::max(0, gx0); gx1 = std::min(grid_cols-1, gx1);
        gy0 = std::max(0, gy0); gy1 = std::min(grid_rows-1, gy1);
        int count = 0;
        for (int gy = gy0; gy <= gy1; ++gy) {
            for (int gx = gx0; gx <= gx1; ++gx) {
                for (const auto& pt : grid[gy*grid_cols + gx]) {
                    double dx = pt.first - u;
                    double dy = pt.second - v;
                    if (dx*dx + dy*dy <= radius*radius) count++;
                }
            }
        }
        densities[i] = count;
    }
    return densities;
}

// ================= processSegment 函数 =================
bool SelfVehicleNode::processSegment(const PointData& prev, const PointData& cur,
    const cv::Mat& img_b, const cv::Point2d blind_pts[4], cv::Mat& output) {
    if (!ENABLE_SEGMENT_FILL) return false;
    const double rad_diff = std::remainder(cur.azimuth - prev.azimuth, 2.0 * M_PI);
    if (std::abs(rad_diff) * 180.0 / M_PI < deg_thresh_) return false;
    int judge = region_judge(cv::Point2d(prev.u_a, prev.v_a), cv::Point2d(cur.u_a, cur.v_a),
                             left_top_blind_, right_bottom_blind_);
    double avg_depth = (prev.depth_self + cur.depth_self) * 0.5;
    double depth_scale = getDepthScale(avg_depth);
    cv::Point2d center_b((prev.u_b + cur.u_b)/2.0, (prev.v_b + cur.v_b)/2.0);
    double angle_b_rad = std::atan2(cur.v_b - prev.v_b, cur.u_b - prev.u_b);
    double angle_b_deg = angle_b_rad * 180.0 / M_PI;
    double dist_b = cv::norm(cv::Point2d(cur.u_b - prev.u_b, cur.v_b - prev.v_b));
    if (dist_b < EPS) return false;
    int width_b = static_cast<int>(std::round(dist_b));
    int height_b = static_cast<int>(std::round(patch_rows_ * depth_scale));
    if (width_b <= 0 || height_b <= 0) return false;
    width_b = std::min(width_b, img_b.cols * 2);
    height_b = std::min(height_b, img_b.rows * 2);
    cv::Size rect_size(width_b, height_b);
    cv::Point2d center_b_clamped = center_b;
    center_b_clamped.x = std::max(0.0, std::min(center_b_clamped.x, (double)img_b.cols-1));
    center_b_clamped.y = std::max(0.0, std::min(center_b_clamped.y, (double)img_b.rows-1));
    cv::RotatedRect rect_b_rot(center_b_clamped, rect_size, angle_b_deg);
    cv::Mat rotated, patch_b;
    try {
        cv::Mat rmat = cv::getRotationMatrix2D(rect_b_rot.center, angle_b_deg, 1.0);
        cv::warpAffine(img_b, rotated, rmat, img_b.size(), cv::INTER_NEAREST);
        if (rotated.empty()) return false;
        cv::getRectSubPix(rotated, rect_size, rect_b_rot.center, patch_b);
        if (patch_b.empty()) return false;
    } catch(...) { return false; }
    if (depth_scale != 1.0) cv::resize(patch_b, patch_b, cv::Size(), depth_scale, depth_scale, cv::INTER_LINEAR);
    if (DEBUG_GREEN_PATCH) patch_b = cv::Mat(patch_b.size(), patch_b.type(), cv::Scalar(0,255,0));

    cv::Point2d start_a, end_a;
    bool valid = false;
    double ratio1=0, ratio2=0;
    if (judge == 0) {
        cv::Point2d result_pts[2]; double ratio[2];
        intersection_region_2pts(cv::Point2d(prev.u_a, prev.v_a), cv::Point2d(cur.u_a, cur.v_a), blind_pts, result_pts, ratio);
        if (result_pts[0].x>0 && result_pts[1].x>0) { start_a=result_pts[0]; end_a=result_pts[1]; ratio1=ratio[0]; ratio2=ratio[1]; valid=true; }
    } else if (judge == 1) {
        cv::Point2d inter = intersection_region(cv::Point2d(prev.u_a, prev.v_a), cv::Point2d(cur.u_a, cur.v_a), blind_pts);
        if (inter.x>0) {
            start_a=inter; end_a=cv::Point2d(cur.u_a, cur.v_a);
            double len_prev_inter = cv::norm(inter - cv::Point2d(prev.u_a, prev.v_a));
            double len_prev_cur = cv::norm(cv::Point2d(cur.u_a, cur.v_a) - cv::Point2d(prev.u_a, prev.v_a));
            ratio1 = len_prev_inter / len_prev_cur; ratio2=1.0; valid=true;
        }
    } else if (judge == 2) {
        cv::Point2d inter = intersection_region(cv::Point2d(prev.u_a, prev.v_a), cv::Point2d(cur.u_a, cur.v_a), blind_pts);
        if (inter.x>0) {
            start_a=cv::Point2d(prev.u_a, prev.v_a); end_a=inter;
            double len_inter_cur = cv::norm(inter - cv::Point2d(cur.u_a, cur.v_a));
            double len_prev_cur = cv::norm(cv::Point2d(cur.u_a, cur.v_a) - cv::Point2d(prev.u_a, prev.v_a));
            ratio1=0.0; ratio2=1.0 - len_inter_cur / len_prev_cur; valid=true;
        }
    } else {
        start_a=cv::Point2d(prev.u_a, prev.v_a); end_a=cv::Point2d(cur.u_a, cur.v_a);
        ratio1=0.0; ratio2=1.0; valid=true;
    }
    if (!valid) return false;

    cv::Mat sub_patch; cv::Point2f sub_src_pts[3];
    if (judge == 0) {
        int col_start = static_cast<int>(std::round(ratio1 * patch_b.cols));
        int col_end   = static_cast<int>(std::round(ratio2 * patch_b.cols));
        col_start = std::max(0, std::min(patch_b.cols, col_start));
        col_end   = std::max(0, std::min(patch_b.cols, col_end));
        if (col_start >= col_end) return false;
        sub_patch = patch_b(cv::Rect(col_start, 0, col_end - col_start, patch_b.rows));
        sub_src_pts[0] = cv::Point2f(0,0); sub_src_pts[1] = cv::Point2f(sub_patch.cols,0); sub_src_pts[2] = cv::Point2f(0,sub_patch.rows);
    } else if (judge == 1) {
        int col_start = static_cast<int>(std::round(ratio1 * patch_b.cols));
        col_start = std::max(0, std::min(patch_b.cols, col_start));
        if (col_start >= patch_b.cols) return false;
        sub_patch = patch_b(cv::Rect(col_start, 0, patch_b.cols - col_start, patch_b.rows));
        sub_src_pts[0] = cv::Point2f(0,0); sub_src_pts[1] = cv::Point2f(sub_patch.cols,0); sub_src_pts[2] = cv::Point2f(0,sub_patch.rows);
    } else if (judge == 2) {
        int col_end = static_cast<int>(std::round(ratio2 * patch_b.cols));
        col_end = std::max(0, std::min(patch_b.cols, col_end));
        if (col_end <= 0) return false;
        sub_patch = patch_b(cv::Rect(0, 0, col_end, patch_b.rows));
        sub_src_pts[0] = cv::Point2f(0,0); sub_src_pts[1] = cv::Point2f(sub_patch.cols,0); sub_src_pts[2] = cv::Point2f(0,sub_patch.rows);
    } else {
        sub_patch = patch_b.clone();
        sub_src_pts[0] = cv::Point2f(0,0); sub_src_pts[1] = cv::Point2f(sub_patch.cols,0); sub_src_pts[2] = cv::Point2f(0,sub_patch.rows);
    }
    if (sub_patch.empty() || sub_patch.cols<=0 || sub_patch.rows<=0) return false;

    cv::Point2d vec_a = end_a - start_a;
    double len_a = cv::norm(vec_a);
    if (len_a < EPS) return false;
    cv::Point2d dir_a = vec_a / len_a;
    cv::Point2d perp_a(-dir_a.y, dir_a.x);
    cv::Point2d center_a = (start_a + end_a) / 2.0;
    double half_width = (patch_rows_ * depth_scale) / 2.0;
    double half_len = len_a / 2.0;
    cv::Point2f dst_pts[3];
    dst_pts[0] = cv::Point2f(center_a.x - half_len*dir_a.x - half_width*perp_a.x, center_a.y - half_len*dir_a.y - half_width*perp_a.y);
    dst_pts[1] = cv::Point2f(center_a.x + half_len*dir_a.x - half_width*perp_a.x, center_a.y + half_len*dir_a.y - half_width*perp_a.y);
    dst_pts[2] = cv::Point2f(center_a.x - half_len*dir_a.x + half_width*perp_a.x, center_a.y - half_len*dir_a.y + half_width*perp_a.y);
    if (dst_pts[0].x<0||dst_pts[0].x>=output.cols||dst_pts[0].y<0||dst_pts[0].y>=output.rows ||
        dst_pts[1].x<0||dst_pts[1].x>=output.cols||dst_pts[1].y<0||dst_pts[1].y>=output.rows ||
        dst_pts[2].x<0||dst_pts[2].x>=output.cols||dst_pts[2].y<0||dst_pts[2].y>=output.rows) return false;
    try {
        cv::Mat affine_mat = cv::getAffineTransform(sub_src_pts, dst_pts);
        cv::warpAffine(sub_patch, output, affine_mat, output.size(), cv::INTER_NEAREST, cv::BORDER_TRANSPARENT);
        return true;
    } catch(...) { return false; }
}

// ---------- 核心点云处理 ----------
void SelfVehicleNode::points_callback(const sensor_msgs::msg::PointCloud2::ConstSharedPtr cloud_b) {
    try {
        sensor_msgs::msg::Image::ConstSharedPtr image_a, image_b;
        geometry_msgs::msg::PoseStamped::ConstSharedPtr pose_a, pose_b;
        bool exact_a=false, exact_b=false, exact_pose_a=false, exact_pose_b=false;
        {
            std::lock_guard<std::mutex> lock(data_mutex_);
            if (!getClosest(image_a_history_, cloud_b->header.stamp, image_a, SYNC_MAX_TIME_DIFF, exact_a) ||
                !getClosest(image_b_history_, cloud_b->header.stamp, image_b, SYNC_MAX_TIME_DIFF, exact_b) ||
                !getClosest(pose_a_history_, cloud_b->header.stamp, pose_a, SYNC_MAX_TIME_DIFF, exact_pose_a) ||
                !getClosest(pose_b_history_, cloud_b->header.stamp, pose_b, SYNC_MAX_TIME_DIFF, exact_pose_b)) {
                RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 3000, "Missing sync data");
                return;
            }
        }
        if (!intrinsic_self_ready_ || !intrinsic_other_ready_) {
            RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 3000, "Waiting for intrinsic");
            return;
        }
        {
            std::lock_guard<std::mutex> lock(g_other_extrinsic_mutex);
            if (!g_other_extrinsic_initialized) {
                RCLCPP_ERROR(this->get_logger(), "Other extrinsic not initialized");
                return;
            }
        }

        const Eigen::Vector3d t_WA(pose_a->pose.position.x, pose_a->pose.position.y, pose_a->pose.position.z);
        const Eigen::Matrix3d R_WA = quat_to_matrix(pose_a->pose.orientation);
        const Eigen::Matrix3d R_AW = R_WA.transpose();
        const Eigen::Vector3d t_WB(pose_b->pose.position.x, pose_b->pose.position.y, pose_b->pose.position.z);
        const Eigen::Matrix3d R_WB = quat_to_matrix(pose_b->pose.orientation);

        std::map<uint16_t, std::vector<PointData>> points_by_ch;
        parse_pointcloud(cloud_b, points_by_ch);

        cv::Mat img_a, img_b_cv;
        try {
            img_a = cv_bridge::toCvCopy(image_a, "bgr8")->image;
            img_b_cv = cv_bridge::toCvCopy(image_b, "bgr8")->image;
        } catch (const cv_bridge::Exception& e) {
            RCLCPP_ERROR(this->get_logger(), "cv_bridge error: %s", e.what());
            return;
        }
        if (img_a.empty() || img_b_cv.empty()) { RCLCPP_ERROR(this->get_logger(), "Empty image(s)"); return; }

        cv::Mat output = img_a.clone();
        cv::Mat another_processed = img_b_cv.clone();
        cv::Point2d blind_pts[4] = { left_top_blind_, cv::Point2d(right_bottom_blind_.x, left_top_blind_.y),
                                     right_bottom_blind_, cv::Point2d(left_top_blind_.x, right_bottom_blind_.y) };

        // 第一遍：计算所有有效点的投影坐标
        struct TempPoint { double u,v; PointData* ptr; };
        std::vector<TempPoint> temp_points; temp_points.reserve(10000);
        double u_min=1e9, u_max=-1e9, v_min=1e9, v_max=-1e9;
        // 获取他车外参（只读一次，避免重复加锁）
        Eigen::Matrix3d R_LC_other;
        Eigen::Vector3d t_LC_other;
        {
            std::lock_guard<std::mutex> lock(g_other_extrinsic_mutex);
            R_LC_other = g_R_LC_other;
            t_LC_other = g_t_LC_other;
        }
        for (auto& [ch, vec] : points_by_ch) {
            for (auto& p : vec) {
                const Eigen::Vector3d p_B_lidar(p.x, p.y, p.z);
                const Eigen::Vector3d p_B_cam = R_LC_other * p_B_lidar + t_LC_other;
                double X_b = -p_B_cam.y(), Y_b = p_B_cam.z(), Z_b = p_B_cam.x();
                const Eigen::Vector3d p_w = R_WB * p_B_lidar + t_WB;
                const Eigen::Vector3d p_A = R_AW * (p_w - t_WA);
                const Eigen::Vector3d p_sc = R_LC_self_ * p_A + t_LC_self_;
                double X = -p_sc.y(), Y = p_sc.z(), Z = p_sc.x();
                if (Z <= 0.1) continue;
                double x_norm = X/Z, y_norm = Y/Z, xd, yd;
                applyDistortion(x_norm, y_norm, dist_coeff_self_, selfD_count_, xd, yd);
                double u_a = fx_self_ * xd + cx_self_;
                double v_a = fy_self_ * yd + cy_self_;
                if (u_a<0 || u_a>=width_self_ || v_a<0 || v_a>=height_self_) continue;
                u_a += POINT_CLOUD_SHIFT_U;
                v_a += POINT_CLOUD_SHIFT_V;
                p.u_a = u_a; p.v_a = v_a; p.depth_self = Z; p.valid = true;
                if (Z_b <= 0.1) { p.u_b = -1; p.v_b = -1; }
                else {
                    double x_norm_b = X_b/Z_b, y_norm_b = Y_b/Z_b, xd_b, yd_b;
                    applyDistortion(x_norm_b, y_norm_b, dist_coeff_other_, otherD_count_, xd_b, yd_b);
                    double u_b = fx_other_ * xd_b + cx_other_;
                    double v_b = fy_other_ * yd_b + cy_other_;
                    if (!in_image(u_b, v_b, width_other_, height_other_)) { p.u_b = -1; p.v_b = -1; }
                    else { p.u_b = u_b; p.v_b = v_b; }
                }
                temp_points.push_back({u_a, v_a, &p});
                u_min = std::min(u_min, u_a); u_max = std::max(u_max, u_a);
                v_min = std::min(v_min, v_a); v_max = std::max(v_max, v_a);
            }
        }
        if (temp_points.empty()) { RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 3000, "No valid points"); return; }

        // ================= 动态 ROI 计算与平滑（抗抖动） =================
        int roi_left=0, roi_right=width_self_, roi_top=0, roi_bottom=height_self_;
        if (DYNAMIC_ROI_ENABLED) {
            int raw_left = static_cast<int>(u_min), raw_right = static_cast<int>(u_max)+1;
            int raw_top = static_cast<int>(v_min), raw_bottom = static_cast<int>(v_max)+1;
            raw_left += ROI_EXPAND_HORIZONTAL; raw_right -= ROI_EXPAND_HORIZONTAL;
            raw_top += ROI_EXPAND_VERTICAL; raw_bottom -= ROI_EXPAND_VERTICAL;
            raw_left += ROI_SHIFT_U; raw_right += ROI_SHIFT_U;
            raw_top += ROI_SHIFT_V; raw_bottom += ROI_SHIFT_V;
            // 钳位到图像范围
            raw_left   = std::max(0, raw_left);
            raw_right  = std::min(width_self_, raw_right);
            raw_top    = std::max(0, raw_top);
            raw_bottom = std::min(height_self_, raw_bottom);

            // 指数移动平均平滑
            if (!roi_initialized_) {
                smoothed_roi_left_   = raw_left;
                smoothed_roi_right_  = raw_right;
                smoothed_roi_top_    = raw_top;
                smoothed_roi_bottom_ = raw_bottom;
                roi_initialized_ = true;
            } else {
                double alpha = roi_smoothing_alpha_;
                smoothed_roi_left_   = alpha * raw_left   + (1.0 - alpha) * smoothed_roi_left_;
                smoothed_roi_right_  = alpha * raw_right  + (1.0 - alpha) * smoothed_roi_right_;
                smoothed_roi_top_    = alpha * raw_top    + (1.0 - alpha) * smoothed_roi_top_;
                smoothed_roi_bottom_ = alpha * raw_bottom + (1.0 - alpha) * smoothed_roi_bottom_;
            }

            roi_left   = static_cast<int>(std::round(smoothed_roi_left_));
            roi_right  = static_cast<int>(std::round(smoothed_roi_right_));
            roi_top    = static_cast<int>(std::round(smoothed_roi_top_));
            roi_bottom = static_cast<int>(std::round(smoothed_roi_bottom_));

            // 确保有效尺寸
            if (roi_left >= roi_right) roi_right = roi_left + 1;
            if (roi_top >= roi_bottom) roi_bottom = roi_top + 1;

            if (DRAW_ROI_RECT) cv::rectangle(output, cv::Point(roi_left,roi_top), cv::Point(roi_right-1,roi_bottom-1), cv::Scalar(255,0,0), 2);
        }
        // =================================================================

        // 筛选 ROI 内的点
        std::vector<PointData*> roi_points;
        for (auto& tmp : temp_points) {
            if (DYNAMIC_ROI_ENABLED && (tmp.u < roi_left || tmp.u >= roi_right || tmp.v < roi_top || tmp.v >= roi_bottom)) continue;
            roi_points.push_back(tmp.ptr);
        }
        if (roi_points.empty()) { RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 3000, "No points in ROI"); return; }

        // 稀疏插值（在每个 channel 内对 ROI 点进行）
        std::map<uint16_t, std::vector<PointData>> points_by_ch_roi;
        for (auto p : roi_points) points_by_ch_roi[p->channel].push_back(*p);
        for (auto& [ch, vec] : points_by_ch_roi) {
            if (vec.size() < 2) continue;
            std::sort(vec.begin(), vec.end(), [](const PointData& a, const PointData& b) { return a.azimuth < b.azimuth; });
            std::vector<PointData> expanded; expanded.reserve(vec.size()*2);
            for (size_t i = 0; i < vec.size(); ++i) {
                expanded.push_back(vec[i]);
                if (i+1 < vec.size()) {
                    double dist = cv::norm(cv::Point2d(vec[i+1].u_a - vec[i].u_a, vec[i+1].v_a - vec[i].v_a));
                    if (dist > SPARSE_DIST_THRESH) {
                        int num = std::min(MAX_INTERP_POINTS, static_cast<int>(dist / SPARSE_DIST_THRESH));
                        for (int k=1; k<=num; ++k) {
                            double t = static_cast<double>(k)/(num+1);
                            PointData interp;
                            interp.u_a = vec[i].u_a*(1-t)+vec[i+1].u_a*t;
                            interp.v_a = vec[i].v_a*(1-t)+vec[i+1].v_a*t;
                            interp.u_b = vec[i].u_b*(1-t)+vec[i+1].u_b*t;
                            interp.v_b = vec[i].v_b*(1-t)+vec[i+1].v_b*t;
                            interp.depth_self = vec[i].depth_self*(1-t)+vec[i+1].depth_self*t;
                            interp.azimuth = vec[i].azimuth*(1-t)+vec[i+1].azimuth*t;
                            interp.channel = ch; interp.valid = true;
                            expanded.push_back(interp);
                        }
                    }
                }
            }
            points_by_ch_roi[ch] = expanded;
        }

        // 收集所有待处理点（用于密度统计和累积渲染）
        std::vector<PointData> all_points;
        for (auto& [ch, vec] : points_by_ch_roi) all_points.insert(all_points.end(), vec.begin(), vec.end());
        if (all_points.empty()) return;

        // 计算每个点的局部密度
        std::vector<int> densities = computeDensities(all_points, DENSITY_RADIUS, width_self_, height_self_);

        // 创建累积缓冲区（仅对 ROI 区域）
        cv::Mat accum_color = cv::Mat::zeros(output.size(), CV_32FC3);
        cv::Mat accum_weight = cv::Mat::zeros(output.size(), CV_32FC1);

        // 矩形拷贝累积（如果启用）
        if (ENABLE_RECT_COPY) {
            for (size_t idx = 0; idx < all_points.size(); ++idx) {
                const auto& p = all_points[idx];
                if (p.u_b < 0 || p.v_b < 0) continue;  // 无效纹理源
                int src_cx = static_cast<int>(std::round(p.u_b));
                int src_cy = static_cast<int>(std::round(p.v_b));
                int dst_cx = static_cast<int>(std::round(p.u_a));
                int dst_cy = static_cast<int>(std::round(p.v_a));
                if (dst_cx < roi_left || dst_cx >= roi_right || dst_cy < roi_top || dst_cy >= roi_bottom) continue;

                // 深度缩放
                double depth_scale = getDepthScale(p.depth_self);
                // 密度缩放
                double density_scale = std::min(MAX_DENSITY_SCALE, std::max(MIN_DENSITY_SCALE, BASE_DENSITY / (densities[idx] + 1.0)));
                int rect_w = static_cast<int>(std::round(BASE_PATCH_COLS * depth_scale * density_scale));
                int rect_h = static_cast<int>(std::round(BASE_PATCH_ROWS * depth_scale * density_scale));
                rect_w = std::min(MAX_RECT_SIZE, std::max(MIN_RECT_SIZE, rect_w));
                rect_h = std::min(MAX_RECT_SIZE, std::max(MIN_RECT_SIZE, rect_h));
                int half_w = rect_w / 2, half_h = rect_h / 2;

                cv::Rect src_rect(src_cx - half_w, src_cy - half_h, rect_w, rect_h);
                cv::Rect dst_rect(dst_cx - half_w, dst_cy - half_h, rect_w, rect_h);
                src_rect = src_rect & cv::Rect(0, 0, img_b_cv.cols, img_b_cv.rows);
                dst_rect = dst_rect & cv::Rect(0, 0, output.cols, output.rows);
                if (src_rect.width <= 0 || src_rect.height <= 0 || dst_rect.width <= 0 || dst_rect.height <= 0) continue;

                cv::Mat src_roi = img_b_cv(src_rect);
                if (src_roi.size() != dst_rect.size()) {
                    cv::resize(src_roi, src_roi, dst_rect.size(), 0, 0, cv::INTER_LINEAR);
                }

                // 高斯权重
                double sigma = std::min(rect_w, rect_h) * 0.5 * GAUSS_SIGMA_FACTOR;
                double sigma2 = sigma * sigma;
                int center_x = dst_rect.width / 2, center_y = dst_rect.height / 2;
                for (int dy = 0; dy < dst_rect.height; ++dy) {
                    int y_global = dst_rect.y + dy;
                    cv::Vec3f* accum_color_row = accum_color.ptr<cv::Vec3f>(y_global);
                    float* accum_weight_row = accum_weight.ptr<float>(y_global);
                    cv::Vec3b* src_row = src_roi.ptr<cv::Vec3b>(dy);
                    int dx2 = (dy - center_y)*(dy - center_y);
                    for (int dx = 0; dx < dst_rect.width; ++dx) {
                        int x_global = dst_rect.x + dx;
                        double dist2 = (dx - center_x)*(dx - center_x) + dx2;
                        double weight = getGaussianWeight(dist2, sigma2);
                        if (weight < 0.01) continue;
                        // 累加
                        accum_color_row[x_global][0] += src_row[dx][0] * weight;
                        accum_color_row[x_global][1] += src_row[dx][1] * weight;
                        accum_color_row[x_global][2] += src_row[dx][2] * weight;
                        accum_weight_row[x_global] += weight;
                    }
                }
            }

            // 归一化累积缓冲区并写入 output（保留自车背景）
            for (int y = roi_top; y < roi_bottom; ++y) {
                cv::Vec3f* accum_color_row = accum_color.ptr<cv::Vec3f>(y);
                float* accum_weight_row = accum_weight.ptr<float>(y);
                cv::Vec3b* out_row = output.ptr<cv::Vec3b>(y);
                for (int x = roi_left; x < roi_right; ++x) {
                    float w = accum_weight_row[x];
                    if (w > 0.01f) {
                        out_row[x][0] = static_cast<uchar>(std::min(255.0f, accum_color_row[x][0] / w));
                        out_row[x][1] = static_cast<uchar>(std::min(255.0f, accum_color_row[x][1] / w));
                        out_row[x][2] = static_cast<uchar>(std::min(255.0f, accum_color_row[x][2] / w));
                    }
                }
            }
        }

        // 线段填补（可选）
        if (ENABLE_SEGMENT_FILL) {
            for (auto& [ch, vec] : points_by_ch_roi) {
                if (vec.size() < 2) continue;
                std::sort(vec.begin(), vec.end(), [](const PointData& a, const PointData& b) { return a.azimuth < b.azimuth; });
                for (size_t i = 0; i+1 < vec.size(); ++i) processSegment(vec[i], vec[i+1], img_b_cv, blind_pts, output);
                const auto& first = vec.front(), last = vec.back();
                double rad_diff = std::abs(std::remainder(first.azimuth - last.azimuth, 2.0*M_PI));
                if (rad_diff * 180.0 / M_PI >= deg_thresh_) processSegment(last, first, img_b_cv, blind_pts, output);
            }
        }

        // 深度变形（他车图像）
        if (ENABLE_DEPTH_DEFORMATION && !all_points.empty() && !another_processed.empty()) {
            cv::Mat depth_map = cv::Mat::zeros(another_processed.size(), CV_32FC1);
            cv::Mat weight_map = cv::Mat::zeros(another_processed.size(), CV_32FC1);
            for (const auto& p : all_points) {
                if (p.u_b < 0) continue;
                int u = static_cast<int>(std::round(p.u_b)), v = static_cast<int>(std::round(p.v_b));
                double depth = p.depth_self;
                if (depth <= 0.0) continue;
                for (int dy = -DEPTH_RADIUS; dy <= DEPTH_RADIUS; ++dy) {
                    for (int dx = -DEPTH_RADIUS; dx <= DEPTH_RADIUS; ++dx) {
                        if (dx*dx+dy*dy > DEPTH_RADIUS*DEPTH_RADIUS) continue;
                        int x = u+dx, y = v+dy;
                        if (x<0 || x>=another_processed.cols || y<0 || y>=another_processed.rows) continue;
                        depth_map.at<float>(y,x) += static_cast<float>(depth);
                        weight_map.at<float>(y,x) += 1.0f;
                    }
                }
            }
            for (int y=0; y<another_processed.rows; ++y) for (int x=0; x<another_processed.cols; ++x) {
                float w = weight_map.at<float>(y,x);
                if (w>0) depth_map.at<float>(y,x) /= w;
                else depth_map.at<float>(y,x) = static_cast<float>(MAX_DEPTH_FOR_SCALE);
            }
            cv::GaussianBlur(depth_map, depth_map, cv::Size(GAUSS_KERNEL,GAUSS_KERNEL), GAUSS_SIGMA);
            cv::Mat map_x(another_processed.size(), CV_32FC1), map_y(another_processed.size(), CV_32FC1);
            float cx = another_processed.cols/2.0f, cy = another_processed.rows/2.0f;
            for (int y=0; y<another_processed.rows; ++y) for (int x=0; x<another_processed.cols; ++x) {
                float depth = depth_map.at<float>(y,x);
                float t = (depth - MIN_DEPTH_FOR_SCALE) / (MAX_DEPTH_FOR_SCALE - MIN_DEPTH_FOR_SCALE);
                t = std::min(1.0f, std::max(0.0f, t));
                float scale = MAX_SCALE*(1-t) + MIN_SCALE*t;
                float dx = x-cx, dy = y-cy;
                map_x.at<float>(y,x) = cx + dx*scale;
                map_y.at<float>(y,x) = cy + dy*scale;
            }
            cv::Mat deformed;
            cv::remap(another_processed, deformed, map_x, map_y, cv::INTER_LINEAR, cv::BORDER_CONSTANT, cv::Scalar(0,0,0));
            another_processed = deformed;
        }

        // 发布原始结果（BGR8）
        auto out_msg = cv_bridge::CvImage(image_a->header, "bgr8", output).toImageMsg();
        result_pub_.publish(out_msg);

        // 可选：发布 /another_image_processed（BGR8）
        if (ENABLE_ANOTHER_PROCESSED_PUB) {
            auto another_msg = cv_bridge::CvImage(image_b->header, "bgr8", another_processed).toImageMsg();
            another_processed_pub_.publish(another_msg);
        }

        // ========== 生成并发布 /localize_image_prime（BGR8画布） ==========
        if (ENABLE_RECT_COPY) {
            cv::Mat blended(output.size(), CV_32FC3, cv::Scalar(0,0,0));
            for (int y = roi_top; y < roi_bottom; ++y) {
                cv::Vec3f* accum_color_row = accum_color.ptr<cv::Vec3f>(y);
                float* accum_weight_row = accum_weight.ptr<float>(y);
                cv::Vec3f* blended_row = blended.ptr<cv::Vec3f>(y);
                for (int x = roi_left; x < roi_right; ++x) {
                    float w = accum_weight_row[x];
                    if (w > 0.01f) {
                        blended_row[x][0] = std::min(255.0f, accum_color_row[x][0] / w);
                        blended_row[x][1] = std::min(255.0f, accum_color_row[x][1] / w);
                        blended_row[x][2] = std::min(255.0f, accum_color_row[x][2] / w);
                    }
                }
            }

            int roi_w = roi_right - roi_left;
            int roi_h = roi_bottom - roi_top;
            if (roi_w > 0 && roi_h > 0) {
                cv::Mat roi_blended = blended(cv::Rect(roi_left, roi_top, roi_w, roi_h));
                roi_blended.convertTo(roi_blended, CV_8UC3);  // 转换为 BGR8
                double scale_x = static_cast<double>(CANVAS_WIDTH) / roi_w;
                double scale_y = static_cast<double>(CANVAS_HEIGHT) / roi_h;
                double scale = std::min(scale_x, scale_y);
                int dst_w = static_cast<int>(std::round(roi_w * scale));
                int dst_h = static_cast<int>(std::round(roi_h * scale));
                cv::Mat resized;
                cv::resize(roi_blended, resized, cv::Size(dst_w, dst_h), 0, 0, cv::INTER_LANCZOS4);

                // 非锐化掩模（USM）
                if (ENABLE_SHARPEN) {
                    cv::Mat blurred, sharpened;
                    cv::GaussianBlur(resized, blurred, cv::Size(0,0), SHARPEN_SIGMA);
                    cv::addWeighted(resized, 1.0 + SHARPEN_AMOUNT, blurred, -SHARPEN_AMOUNT, 0.0, sharpened);
                    if (SHARPEN_THRESHOLD > 0.0) {
                        cv::Mat diff, mask;
                        cv::absdiff(resized, blurred, diff);
                        cv::cvtColor(diff, diff, cv::COLOR_BGR2GRAY);
                        cv::threshold(diff, mask, SHARPEN_THRESHOLD, 255, cv::THRESH_BINARY);
                        resized.copyTo(sharpened, mask);
                    }
                    resized = sharpened;
                }

                cv::Mat canvas = cv::Mat::zeros(CANVAS_HEIGHT, CANVAS_WIDTH, CV_8UC3);
                int offset_x = (CANVAS_WIDTH - dst_w) / 2;
                int offset_y = (CANVAS_HEIGHT - dst_h) / 2;
                resized.copyTo(canvas(cv::Rect(offset_x, offset_y, dst_w, dst_h)));
                std_msgs::msg::Header canvas_header = image_a->header;
                canvas_header.frame_id = "canvas";
                auto canvas_msg = cv_bridge::CvImage(canvas_header, "bgr8", canvas).toImageMsg();
                canvas_pub_->publish(*canvas_msg);
            } else {
                RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 1000, "ROI zero size, cannot create canvas");
            }
        }
        // =====================================================

    } catch (const std::exception& e) {
        RCLCPP_ERROR(this->get_logger(), "Exception: %s", e.what());
    } catch (...) {
        RCLCPP_ERROR(this->get_logger(), "Unknown exception");
    }
}

} // namespace self_vehicle

int main(int argc, char* argv[]) {
    rclcpp::init(argc, argv);
    auto node = std::make_shared<self_vehicle::SelfVehicleNode>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}