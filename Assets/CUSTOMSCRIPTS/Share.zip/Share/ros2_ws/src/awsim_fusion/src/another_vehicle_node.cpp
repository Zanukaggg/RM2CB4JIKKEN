#include "another_vehicle.hpp"
#include <cv_bridge/cv_bridge.h>
#include <algorithm>
#include <cmath>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>

namespace another_vehicle
{

AnotherVehicleNode::AnotherVehicleNode() : Node("another_vehicle")
{
    this->declare_parameter("transform_x", 0.0);
    this->declare_parameter("transform_y", 0.0);
    this->declare_parameter("transform_z", 0.0);
    this->declare_parameter("roll_offset", 0.0);
    this->declare_parameter("pitch_offset", 0.0);
    this->declare_parameter("yaw_offset", 0.0);
    this->declare_parameter("FOV", 84.9);
    this->declare_parameter("max_range", 120.0);
    this->declare_parameter("vlp16_angles", std::vector<double>{
        -15.0, 1.0, -13.0, 3.0, -11.0, 5.0, -9.0, 7.0,
        -7.0, 9.0, -5.0, 11.0, -3.0, 13.0, -1.0, 15.0});
    this->declare_parameter("sync_max_time_diff", 0.05);

    transform_x_ = this->get_parameter("transform_x").as_double();
    transform_y_ = this->get_parameter("transform_y").as_double();
    transform_z_ = this->get_parameter("transform_z").as_double();
    roll_offset_ = this->get_parameter("roll_offset").as_double();
    pitch_offset_ = this->get_parameter("pitch_offset").as_double();
    yaw_offset_ = this->get_parameter("yaw_offset").as_double();
    double fov = this->get_parameter("FOV").as_double();
    max_tan_ = tan(fov * 0.5 * M_PI / 180.0);
    max_range_ = this->get_parameter("max_range").as_double();
    auto angles_deg = this->get_parameter("vlp16_angles").as_double_array();
    for (size_t i = 0; i < 16 && i < angles_deg.size(); ++i) {
        vert_angle_[i] = angles_deg[i] * M_PI / 180.0;
    }
    for (size_t i = 16; i < 32; ++i) vert_angle_[i] = 0.0;

    phi_left_ = atan2(-1.0, max_tan_);
    phi_right_ = atan2(1.0, max_tan_);

    sync_max_time_diff_ = this->get_parameter("sync_max_time_diff").as_double();

    points_sub_ = this->create_subscription<sensor_msgs::msg::PointCloud2>(
        "/sensing/lidar/top/pointcloud_raw_ex1",
        rclcpp::QoS(5).best_effort(),
        std::bind(&AnotherVehicleNode::points_callback, this, std::placeholders::_1));

    info_sub_ = this->create_subscription<sensor_msgs::msg::CameraInfo>(
        "/sensing/camera/traffic_light/camera_info1",
        rclcpp::QoS(1).best_effort(),
        std::bind(&AnotherVehicleNode::info_callback, this, std::placeholders::_1));

    image_sub_ = image_transport::create_subscription(
        this, "/sensing/camera/traffic_light/image_raw1",
        std::bind(&AnotherVehicleNode::image_callback, this, std::placeholders::_1),
        "raw", rclcpp::QoS(1).best_effort().get_rmw_qos_profile());

    pose_sub_ = this->create_subscription<geometry_msgs::msg::PoseStamped>(
        "/sensing/gnss/pose1",
        10,
        std::bind(&AnotherVehicleNode::pose_callback, this, std::placeholders::_1));

    extrinsic_sub_ = this->create_subscription<geometry_msgs::msg::Transform>(
        "/ano/projection_matrix", 1,
        std::bind(&AnotherVehicleNode::extrinsic_callback, this, std::placeholders::_1));

    auto qos_transient = rclcpp::QoS(1).transient_local();
    cloud_pub_ = this->create_publisher<sensor_msgs::msg::PointCloud2>("/another_cloud", 10);
    image_pub_ = image_transport::create_publisher(this, "/another_image");
    pose_pub_ = this->create_publisher<geometry_msgs::msg::PoseStamped>("/another_pose", 10);
    extrinsic_pub_ = this->create_publisher<geometry_msgs::msg::Transform>("/another_extrinsic", qos_transient);
    intrinsic_pub_ = this->create_publisher<sensor_msgs::msg::CameraInfo>("/another_intrinsic", qos_transient);
    ring_count_pub_ = this->create_publisher<std_msgs::msg::Int16MultiArray>("/ring_count", 10);

    another_cloud_.header.frame_id = "velodyne_top1";
    another_cloud_.height = 1;
    another_cloud_.fields.clear();
    sensor_msgs::msg::PointField f;
    f.name = "x"; f.offset = 0; f.datatype = sensor_msgs::msg::PointField::FLOAT32; f.count = 1;
    another_cloud_.fields.push_back(f);
    f.name = "y"; f.offset = 4; f.datatype = sensor_msgs::msg::PointField::FLOAT32; f.count = 1;
    another_cloud_.fields.push_back(f);
    f.name = "z"; f.offset = 8; f.datatype = sensor_msgs::msg::PointField::FLOAT32; f.count = 1;
    another_cloud_.fields.push_back(f);
    f.name = "channel"; f.offset = 12; f.datatype = sensor_msgs::msg::PointField::FLOAT32; f.count = 1;
    another_cloud_.fields.push_back(f);
    another_cloud_.point_step = 16;
    another_cloud_.is_bigendian = false;
    another_cloud_.is_dense = true;

    // 构建外参矩阵（与原来相同，仅用于转发）
    tf2::Matrix3x3 rotation_base;
    rotation_base.setValue(1, 0, 0, 0, 0, 1, 0, -1, 0);
    tf2::Quaternion q_roll, q_pitch, q_yaw;
    q_roll.setRPY(roll_offset_ * M_PI / 180.0, 0, 0);
    q_pitch.setRPY(0, pitch_offset_ * M_PI / 180.0, 0);
    q_yaw.setRPY(0, 0, yaw_offset_ * M_PI / 180.0);
    tf2::Matrix3x3 rotation_offset = tf2::Matrix3x3(q_yaw) * tf2::Matrix3x3(q_pitch) * tf2::Matrix3x3(q_roll);
    tf2::Matrix3x3 rotation_final = rotation_offset * rotation_base;

    {
        std::lock_guard<std::mutex> lock(extrinsic_mutex_);
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                R_LC_(i, j) = rotation_final[i][j];
            }
        }
        t_LC_(0) = transform_x_;
        t_LC_(1) = transform_y_;
        t_LC_(2) = transform_z_;
        Eigen::Vector3d neg_t = -t_LC_;
        Eigen::Vector3d inv_rt = R_LC_.transpose() * neg_t;
        inv_rt_LC_[0] = inv_rt(0);
        inv_rt_LC_[1] = inv_rt(1);
        inv_rt_LC_[2] = inv_rt(2);
    }

    geometry_msgs::msg::Transform default_extrinsic;
    tf2::Matrix3x3 rot(rotation_final[0][0], rotation_final[0][1], rotation_final[0][2],
                       rotation_final[1][0], rotation_final[1][1], rotation_final[1][2],
                       rotation_final[2][0], rotation_final[2][1], rotation_final[2][2]);
    tf2::Quaternion q;
    rot.getRotation(q);
    default_extrinsic.rotation = tf2::toMsg(q);
    default_extrinsic.translation.x = transform_x_;
    default_extrinsic.translation.y = transform_y_;
    default_extrinsic.translation.z = transform_z_;

    extrinsic_pub_->publish(default_extrinsic);
    projection_flag_ = true;

    // 预分配缓冲区，避免运行时反复分配
    buf_.reserve(100000);
    another_cloud_.data.reserve(100000 * another_cloud_.point_step);
}

void AnotherVehicleNode::info_callback(const sensor_msgs::msg::CameraInfo::SharedPtr msg)
{
    // 检测分辨率是否发生变化
    if (width_ != msg->width || height_ != msg->height) {
        // 分辨率改变，清空图像缓存，避免使用旧尺寸图像
        {
            std::lock_guard<std::mutex> lock(image_history_mutex_);
            image_history_.clear();
        }
        {
            std::lock_guard<std::mutex> lock(last_image_mutex_);
            last_image_.reset();
        }
    }

    fx_ = msg->k[0];
    fy_ = msg->k[4];
    cx_ = msg->k[2];
    cy_ = msg->k[5];
    width_ = msg->width;
    height_ = msg->height;
    intrinsic_flag_ = true;
    intrinsic_pub_->publish(*msg);
}

void AnotherVehicleNode::image_callback(const sensor_msgs::msg::Image::ConstSharedPtr msg)
{
    if (msg->data.empty()) {
        return;
    }
    {
        std::lock_guard<std::mutex> lock(image_history_mutex_);
        image_history_.push_back(msg);
        const size_t MAX_IMAGE_HISTORY = 10;
        while (image_history_.size() > MAX_IMAGE_HISTORY) {
            image_history_.pop_front();
        }
    }
    {
        std::lock_guard<std::mutex> lock(last_image_mutex_);
        last_image_ = msg;
    }
    image_flag_ = true;
}

void AnotherVehicleNode::pose_callback(const geometry_msgs::msg::PoseStamped::SharedPtr msg)
{
    if (msg->pose.orientation.x == 0.0 && msg->pose.orientation.y == 0.0 &&
        msg->pose.orientation.z == 0.0 && msg->pose.orientation.w == 0.0) {
        msg->pose.orientation.w = 1.0;
    }

    {
        std::lock_guard<std::mutex> lock(pose_mutex_);
        pose_history_.push_back(*msg);
        if (pose_history_.size() > MAX_POSE_HISTORY) {
            pose_history_.pop_front();
        }
    }

    transform_WL_[0] = msg->pose.position.x;
    transform_WL_[1] = msg->pose.position.y;
    transform_WL_[2] = msg->pose.position.z;

    orientation_WL_[0] = msg->pose.orientation.x;
    orientation_WL_[1] = msg->pose.orientation.y;
    orientation_WL_[2] = msg->pose.orientation.z;
    orientation_WL_[3] = msg->pose.orientation.w;

    tf2::Quaternion q(
        msg->pose.orientation.x,
        msg->pose.orientation.y,
        msg->pose.orientation.z,
        msg->pose.orientation.w);

    tf2::Matrix3x3 m(q);
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j)
            rotation_WL_[i * 3 + j] = m[i][j];

    pose_flag_ = true;

    pose_pub_->publish(*msg);
}

void AnotherVehicleNode::extrinsic_callback(const geometry_msgs::msg::Transform::SharedPtr msg)
{
    tf2::Quaternion q;
    tf2::fromMsg(msg->rotation, q);
    tf2::Matrix3x3 rot(q);
    tf2::Vector3 trans(msg->translation.x, msg->translation.y, msg->translation.z);

    {
        std::lock_guard<std::mutex> lock(extrinsic_mutex_);
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                R_LC_(i, j) = rot[i][j];
            }
        }
        t_LC_(0) = trans.x();
        t_LC_(1) = trans.y();
        t_LC_(2) = trans.z();

        Eigen::Vector3d neg_t = -t_LC_;
        Eigen::Vector3d inv_rt = R_LC_.transpose() * neg_t;
        inv_rt_LC_[0] = inv_rt(0);
        inv_rt_LC_[1] = inv_rt(1);
        inv_rt_LC_[2] = inv_rt(2);
    }

    projection_flag_ = true;
}

bool AnotherVehicleNode::getPoseAtTime(
    const rclcpp::Time& stamp,
    geometry_msgs::msg::PoseStamped& out_pose) const
{
    std::lock_guard<std::mutex> lock(pose_mutex_);
    if (pose_history_.empty()) return false;

    auto best_it = pose_history_.rbegin();
    double best_diff = std::abs(
        (rclcpp::Time(best_it->header.stamp) - stamp).seconds());

    for (auto it = pose_history_.rbegin(); it != pose_history_.rend(); ++it) {
        double diff = std::abs(
            (rclcpp::Time(it->header.stamp) - stamp).seconds());

        if (diff < best_diff) {
            best_diff = diff;
            best_it = it;
        }
    }

    if (best_diff > 0.3) {
        return false;
    }

    out_pose = *best_it;
    return true;
}

bool AnotherVehicleNode::getClosestImage(
    const rclcpp::Time& stamp,
    sensor_msgs::msg::Image::ConstSharedPtr& out_img,
    double max_diff)
{
    std::lock_guard<std::mutex> lock(image_history_mutex_);
    if (image_history_.empty()) {
        return false;
    }

    auto best_it = image_history_.begin();
    double best_diff = std::abs((rclcpp::Time((*best_it)->header.stamp) - stamp).seconds());

    for (auto it = image_history_.begin(); it != image_history_.end(); ++it) {
        double diff = std::abs((rclcpp::Time((*it)->header.stamp) - stamp).seconds());
        if (diff < best_diff) {
            best_diff = diff;
            best_it = it;
        }
    }

    if (best_diff > max_diff) {
        return false;
    }

    out_img = *best_it;
    return true;
}

void AnotherVehicleNode::points_callback(
    const sensor_msgs::msg::PointCloud2::SharedPtr msg)
{
    if (!projection_flag_ || !intrinsic_flag_ || !pose_flag_) {
        return;
    }

    // 获取最接近的图像（用于后续图像发布）
    sensor_msgs::msg::Image::ConstSharedPtr sync_image;
    bool sync_ok = getClosestImage(msg->header.stamp, sync_image, sync_max_time_diff_);

    cv::Mat img;
    if (sync_ok) {
        img = cv_bridge::toCvCopy(sync_image, "bgr8")->image;
    } else {
        std::lock_guard<std::mutex> lock(last_image_mutex_);
        if (!last_image_) {
            img = cv::Mat::zeros(height_, width_, CV_8UC3);
        } else {
            img = cv_bridge::toCvCopy(last_image_, "bgr8")->image;
        }
    }

    // 解析点云字段偏移（首次调用时缓存）
    if (off_x_ == -1) {
        for (const auto& f : msg->fields) {
            if (f.name == "x") off_x_ = f.offset;
            else if (f.name == "y") off_y_ = f.offset;
            else if (f.name == "z") off_z_ = f.offset;
        }
        if (off_x_ < 0 || off_y_ < 0 || off_z_ < 0) return;
    }

    const uint8_t* ptr = msg->data.data();
    const size_t total = msg->width * msg->height;

    // 复用缓冲区
    buf_.clear();
    buf_.reserve(total);

    // 提前获取外参（一次锁，避免循环内加锁）
    double inv_rx, inv_ry, inv_rz;
    {
        std::lock_guard<std::mutex> lock(extrinsic_mutex_);
        inv_rx = inv_rt_LC_[0];
        inv_ry = inv_rt_LC_[1];
        inv_rz = inv_rt_LC_[2];
    }

    // 处理每个点
    for (size_t i = 0; i < total; ++i) {
        float x = *reinterpret_cast<const float*>(ptr + off_x_);
        float y = *reinterpret_cast<const float*>(ptr + off_y_);
        float z = *reinterpret_cast<const float*>(ptr + off_z_);
        ptr += msg->point_step;

        if (!std::isfinite(x) || !std::isfinite(y) || !std::isfinite(z)) continue;

        // 左手LiDAR -> 右手相机（x→z, y→x, z→y 并调整符号）
        double Xc = -y;
        double Yc = -x;
        double Zc = z;

        if (Xc <= 0) continue;

        // 应用外参逆变换（P_cam = P_lidar - inv_rt）
        double P_cam_x = Xc - inv_rx;
        double P_cam_y = Yc - inv_ry;
        double P_cam_z = Zc - inv_rz;

        // 存储点云（x,y,z,channel）
        buf_.push_back(static_cast<float>(P_cam_x));
        buf_.push_back(static_cast<float>(P_cam_y));
        buf_.push_back(static_cast<float>(P_cam_z));
        buf_.push_back(0.0f); // channel 填充0
    }

    // 发布点云
    another_cloud_.header = msg->header;
    another_cloud_.width = buf_.size() / 4;
    another_cloud_.row_step = another_cloud_.width * another_cloud_.point_step;
    another_cloud_.data.resize(buf_.size() * sizeof(float));
    memcpy(another_cloud_.data.data(), buf_.data(), another_cloud_.data.size());
    cloud_pub_->publish(another_cloud_);

    // 发布图像（直接使用 img，无需克隆）
    auto out = cv_bridge::CvImage(msg->header, "bgr8", img).toImageMsg();
    image_pub_.publish(out);
}

void AnotherVehicleNode::synced_callback(
    const sensor_msgs::msg::PointCloud2::SharedPtr /*cloud*/,
    const sensor_msgs::msg::Image::SharedPtr /*image*/)
{
    // 未使用的回调，保留空实现
}

} // namespace another_vehicle

int main(int argc, char* argv[])
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<another_vehicle::AnotherVehicleNode>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}