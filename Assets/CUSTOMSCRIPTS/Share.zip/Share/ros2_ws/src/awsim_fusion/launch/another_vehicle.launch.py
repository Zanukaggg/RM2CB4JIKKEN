from launch import LaunchDescription
from launch_ros.actions import Node
from launch.substitutions import LaunchConfiguration
from launch.actions import DeclareLaunchArgument

def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('transform_x', default_value='-0.1'),
        DeclareLaunchArgument('transform_y', default_value='-0.05'),
        DeclareLaunchArgument('transform_z', default_value='0.0175'),
        DeclareLaunchArgument('roll_offset', default_value='-90.0'),
        DeclareLaunchArgument('pitch_offset', default_value='0.0'),
        DeclareLaunchArgument('yaw_offset', default_value='0.0'),
        Node(
            package='awsim_fusion',
            executable='another_vehicle',
            name='another_vehicle',
            output='screen',
            parameters=[{
                'transform_x': LaunchConfiguration('transform_x'),
                'transform_y': LaunchConfiguration('transform_y'),
                'transform_z': LaunchConfiguration('transform_z'),
                'roll_offset': LaunchConfiguration('roll_offset'),
                'pitch_offset': LaunchConfiguration('pitch_offset'),
                'yaw_offset': LaunchConfiguration('yaw_offset'),
            }],
            remappings=[
                ('/sensing/lidar/top/pointcloud_raw_ex', '/sensing/lidar/top/pointcloud_raw_ex1'),
                ('/sensing/camera/traffic_light/camera_info1', '/sensing/camera/traffic_light/camera_info1'),
                ('/sensing/camera/traffic_light/image_raw1', '/sensing/camera/traffic_light/image_raw1'),
                ('/another_cloud', '/another_cloud'),
                ('/another_image', '/another_image'),
            ]
        )
    ])