from launch import LaunchDescription
from launch_ros.actions import Node
from launch.substitutions import LaunchConfiguration
from launch.actions import DeclareLaunchArgument

def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('self_transform_x', default_value='-0.1'),
        DeclareLaunchArgument('self_transform_y', default_value='-0.05'),
        DeclareLaunchArgument('self_transform_z', default_value='0.0175'),
        DeclareLaunchArgument('self_roll_offset', default_value='-90.0'),
        DeclareLaunchArgument('self_pitch_offset', default_value='0.0'),
        DeclareLaunchArgument('self_yaw_offset', default_value='0.0'),

        DeclareLaunchArgument('other_transform_x', default_value='-0.1'),
        DeclareLaunchArgument('other_transform_y', default_value='-0.05'),
        DeclareLaunchArgument('other_transform_z', default_value='0.0175'),
        DeclareLaunchArgument('other_roll_offset', default_value='-90.0'),
        DeclareLaunchArgument('other_pitch_offset', default_value='0.0'),
        DeclareLaunchArgument('other_yaw_offset', default_value='0.0'),

        DeclareLaunchArgument('patch_cols', default_value='5'),
        DeclareLaunchArgument('patch_rows', default_value='5'),
        DeclareLaunchArgument('deg_thresh', default_value='5.0'),

        DeclareLaunchArgument('blind_left_top_x', default_value='500.0'),
        DeclareLaunchArgument('blind_left_top_y', default_value='400.0'),
        DeclareLaunchArgument('blind_right_bottom_x', default_value='600.0'),
        DeclareLaunchArgument('blind_right_bottom_y', default_value='500.0'),

        Node(
            package='awsim_fusion',
            executable='self_vehicle',
            name='self_vehicle',
            output='screen',
            respawn=True,
            respawn_delay=2.0,
            parameters=[{
                'use_sim_time': True,

                'self_transform_x': LaunchConfiguration('self_transform_x'),
                'self_transform_y': LaunchConfiguration('self_transform_y'),
                'self_transform_z': LaunchConfiguration('self_transform_z'),
                'self_roll_offset': LaunchConfiguration('self_roll_offset'),
                'self_pitch_offset': LaunchConfiguration('self_pitch_offset'),
                'self_yaw_offset': LaunchConfiguration('self_yaw_offset'),

                'other_transform_x': LaunchConfiguration('other_transform_x'),
                'other_transform_y': LaunchConfiguration('other_transform_y'),
                'other_transform_z': LaunchConfiguration('other_transform_z'),
                'other_roll_offset': LaunchConfiguration('other_roll_offset'),
                'other_pitch_offset': LaunchConfiguration('other_pitch_offset'),
                'other_yaw_offset': LaunchConfiguration('other_yaw_offset'),

                'patch_cols': LaunchConfiguration('patch_cols'),
                'patch_rows': LaunchConfiguration('patch_rows'),
                'deg_thresh': LaunchConfiguration('deg_thresh'),

                'blind_left_top_x': LaunchConfiguration('blind_left_top_x'),
                'blind_left_top_y': LaunchConfiguration('blind_left_top_y'),
                'blind_right_bottom_x': LaunchConfiguration('blind_right_bottom_x'),
                'blind_right_bottom_y': LaunchConfiguration('blind_right_bottom_y'),

                'vlp16_angles': [-15.0, 1.0, -13.0, 3.0, -11.0, 5.0, -9.0, 7.0,
                                 -7.0, 9.0, -5.0, 11.0, -3.0, 13.0, -1.0, 15.0],
            }],
            remappings=[
                ('/sensing/gnss/pose', '/sensing/gnss/pose'),
                ('/sensing/camera/traffic_light/image_raw', '/sensing/camera/traffic_light/image_raw'),
                ('/sensing/camera/traffic_light/camera_info', '/sensing/camera/traffic_light/camera_info'),
                ('/another_cloud', '/another_cloud'),
                ('/another_image', '/another_image'),
                ('/another_intrinsic', '/another_intrinsic'),
                ('/another_extrinsic', '/another_extrinsic'),
                ('/another_pose', '/another_pose'),
                ('/localize_image', '/localize_image'),
            ]
        )
    ])