import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import numpy as np
import time

from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy


class LowLightEnhancerNode(Node):

    def __init__(self):
        super().__init__('low_light_enhancer')

        # ===============================
        # QoS（保持你的策略）
        # ===============================
        self.qos = QoSProfile(
            depth=5,
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            durability=DurabilityPolicy.VOLATILE
        )

        self.sub = self.create_subscription(
            Image,
            '/sensing/camera/traffic_light/image_raw1',
            self.callback,
            self.qos
        )

        self.pub = self.create_publisher(
            Image,
            '/TEST/low_light',
            self.qos
        )

        self.bridge = CvBridge()

        # ===============================
        # 性能控制
        # ===============================
        self.resize_scale = 0.5
        self.min_period = 0.1
        self.last_time = 0.0

        # ===============================
        # 调试：callback 存活
        # ===============================
        self.frame_count = 0

        # ===============================
        # Gamma LUT（预计算）
        # ===============================
        GAMMA_VALUE = 0.45
        self.gamma_lut = np.array(
            [((i / 255.0) ** GAMMA_VALUE) * 255 for i in range(256)],
            dtype=np.uint8
        )

        # ===============================
        # 结构元素（避免每帧重复创建）
        # ===============================
        self.kernel = np.ones((5, 5), np.uint8)

        self.get_logger().info("Low Light Enhancer FIXED Started")

    def callback(self, msg):
        # ===============================
        # callback 存活确认
        # ===============================
        self.frame_count += 1
        if self.frame_count % 30 == 0:
            self.get_logger().info(f"callback alive, frames={self.frame_count}")

        # ===============================
        # 节流
        # ===============================
        now = time.time()
        if now - self.last_time < self.min_period:
            return
        self.last_time = now

        # ===============================
        # ROS → OpenCV
        # ===============================
        try:
            img = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
        except Exception as e:
            self.get_logger().warn(f'cv_bridge failed: {e}')
            return

        # ===============================
        # resize（提前降负载）
        # ===============================
        try:
            img = cv2.resize(
                img,
                None,
                fx=self.resize_scale,
                fy=self.resize_scale,
                interpolation=cv2.INTER_AREA
            )
        except Exception as e:
            self.get_logger().warn(f'resize failed: {e}')
            return

        # ===============================
        # 增强
        # ===============================
        try:
            result = self._enhance_image(img)
        except Exception as e:
            self.get_logger().error(f'Low-light enhancement failed: {e}')
            return

        # ===============================
        # 发布
        # ===============================
        try:
            out_msg = self.bridge.cv2_to_imgmsg(result, encoding='bgr8')
            out_msg.header = msg.header
            self.pub.publish(out_msg)
        except Exception as e:
            self.get_logger().warn(f'Publish failed: {e}')

    def _enhance_image(self, bgr_img):
        """
        低光照增强（反转 + 简化去雾 + gamma）
        """

        # ✅ 防御：空图
        if bgr_img is None or bgr_img.size == 0:
            raise RuntimeError("empty image")

        # ===============================
        # 反转
        # ===============================
        img_inv = 255 - bgr_img
        b, g, r = cv2.split(img_inv)

        # ===============================
        # 最大通道
        # ===============================
        max_map = np.maximum.reduce([b, g, r]).astype(np.uint8)

        # ===============================
        # 膨胀（用预创建 kernel）
        # ===============================
        i_highest = cv2.dilate(max_map, self.kernel, iterations=1)

        # ===============================
        # 大气光估计
        # ===============================
        A = float(np.mean(i_highest))
        A = np.clip(A, 1.0, 255.0)

        # ===============================
        # 透射率
        # ===============================
        t = (i_highest.astype(np.float32) - A) / (255.0 - A + 1e-6)
        t = np.clip(t, 0.15, 1.0)

        # ✅ 防止极端情况 NaN
        if np.isnan(t).any():
            raise RuntimeError("NaN in transmission map")

        # ===============================
        # 恢复
        # ===============================
        img_inv_float = img_inv.astype(np.float32)
        J_inv = ((img_inv_float - A) / (t[:, :, None] + 1e-6)) + A
        J_inv = np.clip(J_inv, 0, 255).astype(np.uint8)

        # ===============================
        # 反转回来
        # ===============================
        J = 255 - J_inv

        # ===============================
        # Gamma
        # ===============================
        final = cv2.LUT(J, self.gamma_lut)

        return final


def main(args=None):
    rclpy.init(args=args)
    node = LowLightEnhancerNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()