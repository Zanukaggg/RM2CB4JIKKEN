import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import time

from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy


class HEEnhancerNode(Node):

    def __init__(self):
        super().__init__('he_enhancer')

        # ===============================
        # QoS（按你要求不改策略，只修 depth）
        # ===============================
        self.qos = QoSProfile(
            depth=5,  # ✅ 修复点1：从1改成5（避免完全收不到）
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            durability=DurabilityPolicy.VOLATILE
        )

        self.sub = self.create_subscription(
            Image,
            '/sensing/camera/traffic_light/image_raw1',
            self.callback,
            self.qos
        )

        self.pub = self.create_publisher(
            Image,
            '/TEST/he_enhanced',
            self.qos
        )

        self.bridge = CvBridge()

        # ===============================
        # 性能控制
        # ===============================
        self.resize_scale = 0.5
        self.min_period = 0.1
        self.last_time = 0.0

        # ✅ 修复点2：确认节点真的在收数据
        self.frame_count = 0

        self.get_logger().info("HE Enhancer FIXED Started")

    def callback(self, msg):
        # ===============================
        # 调试：确认 callback 触发
        # ===============================
        self.frame_count += 1
        if self.frame_count % 30 == 0:
            self.get_logger().info(f"callback alive, frames={self.frame_count}")

        # ===============================
        # 节流
        # ===============================
        now = time.time()
        if now - self.last_time < self.min_period:
            return
        self.last_time = now

        # ===============================
        # ROS -> OpenCV
        # ===============================
        try:
            img = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
        except Exception as e:
            self.get_logger().warn(f'cv_bridge failed: {e}')
            return

        # ===============================
        # resize（提前降负载）
        # ===============================
        try:
            img = cv2.resize(
                img,
                None,
                fx=self.resize_scale,
                fy=self.resize_scale,
                interpolation=cv2.INTER_AREA
            )
        except Exception as e:
            self.get_logger().warn(f'resize failed: {e}')
            return

        # ===============================
        # 图像增强
        # ===============================
        try:
            result = self._enhance_image(img)
        except Exception as e:
            self.get_logger().error(f'Enhancement failed: {e}')
            return

        # ===============================
        # 发布
        # ===============================
        try:
            out_msg = self.bridge.cv2_to_imgmsg(result, encoding='bgr8')
            out_msg.header = msg.header
            self.pub.publish(out_msg)
        except Exception as e:
            self.get_logger().warn(f'Publish failed: {e}')

    def _enhance_image(self, bgr_img):
        """直方图均衡化增强（仅处理V通道）"""

        # ✅ 修复点3：防止空图崩溃
        if bgr_img is None or bgr_img.size == 0:
            raise RuntimeError("empty image")

        hsv = cv2.cvtColor(bgr_img, cv2.COLOR_BGR2HSV)
        h, s, v = cv2.split(hsv)

        v_eq = cv2.equalizeHist(v)

        merged = cv2.merge([h, s, v_eq])
        result = cv2.cvtColor(merged, cv2.COLOR_HSV2BGR)

        return result


def main(args=None):
    rclpy.init(args=args)
    node = HEEnhancerNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()