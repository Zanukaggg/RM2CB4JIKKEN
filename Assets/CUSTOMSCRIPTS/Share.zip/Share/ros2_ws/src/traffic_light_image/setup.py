from setuptools import setup
from glob import glob

package_name = 'traffic_light_image'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/traffic_light_image']),
        ('share/' + package_name, ['package.xml']),
        # 关键：添加 launch 文件的安装路径
        ('share/' + package_name + '/launch', glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Your Name',
    maintainer_email='your@email.com',
    description='Traffic light image processing nodes',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'traffic_light_binary_node = traffic_light_image.traffic_light_binary_node:main',
            'clahe_enhancer_node = traffic_light_image.clahe_enhancer_node:main',
            'low_light_enhancer_node = traffic_light_image.low_light_enhancer_node:main',
            'he_enhancer_node = traffic_light_image.he_enhancer_node:main',
        ],
    },
)