from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration

def generate_launch_description():
    # ================ 1. 定义可调参数 ================
    # 通用参数（所有节点共享）
    resize_scale = DeclareLaunchArgument(
        'resize_scale', default_value='0.5',
        description='Image resize scale (0.1-1.0)'
    )
    
    alpha = DeclareLaunchArgument(
        'alpha', default_value='2.0',
        description='Image contrast adjustment (1.0-5.0)'
    )
    
    beta = DeclareLaunchArgument(
        'beta', default_value='60',
        description='Image brightness adjustment (0-100)'
    )
    
    # 专用参数（可选）
    clahe_clip = DeclareLaunchArgument(
        'clahe_clip', default_value='3.0',
        description='CLAHE clip limit (1.0-10.0)'
    )
    
    low_light_gamma = DeclareLaunchArgument(
        'low_light_gamma', default_value='0.45',
        description='Low light gamma correction (0.1-1.0)'
    )

    # ================ 2. 创建所有节点 ================
    # 1. 二值化节点
    binary_node = Node(
        package='traffic_light_image',
        executable='traffic_light_binary_node',
        name='traffic_light_binary',
        output='screen',
        parameters=[
            {'resize_scale': LaunchConfiguration('resize_scale')}
        ],
        remappings=[
            ('/sensing/camera/traffic_light/image_raw', '/sensing/camera/traffic_light/image_raw'),
            ('/TEST/image_binary', '/TEST/image_binary')
        ]
    )
    
    # 2. CLAHE 增强节点
    clahe_node = Node(
        package='traffic_light_image',
        executable='clahe_enhancer_node',
        name='clahe_enhancer',
        output='screen',
        parameters=[
            {'clip_limit': LaunchConfiguration('clahe_clip')}
        ],
        remappings=[
            ('/sensing/camera/traffic_light/image_raw', '/sensing/camera/traffic_light/image_raw'),
            ('/TEST/clahe_enhanced', '/TEST/clahe_enhanced')
        ]
    )
    
    # 3. 低光照增强节点
    low_light_node = Node(
        package='traffic_light_image',
        executable='low_light_enhancer_node',
        name='low_light_enhancer',
        output='screen',
        parameters=[
            {'gamma': LaunchConfiguration('low_light_gamma')}
        ],
        remappings=[
            ('/sensing/camera/traffic_light/image_raw', '/sensing/camera/traffic_light/image_raw'),
            ('/TEST/low_light', '/TEST/low_light')
        ]
    )
    
    # 4. 直方图均衡化节点
    he_node = Node(
        package='traffic_light_image',
        executable='he_enhancer_node',
        name='he_enhancer',
        output='screen',
        remappings=[
            ('/sensing/camera/traffic_light/image_raw', '/sensing/camera/traffic_light/image_raw'),
            ('/TEST/he_enhanced', '/TEST/he_enhanced')
        ]
    )

    # ================ 3. 创建启动描述 ================
    return LaunchDescription([
        resize_scale,
        alpha,
        beta,
        clahe_clip,
        low_light_gamma,
        binary_node,
        clahe_node,
        low_light_node,
        he_node
    ])