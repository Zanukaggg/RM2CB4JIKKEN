# 图像增强节点 (ROS 2)

## 功能
三个独立的ROS 2节点，分别实现三种图像增强算法：
1. 低光照增强 (`/low_light_enhanced`)
2. CLAHE (对比度受限自适应直方图均衡化) (`/clahe_enhanced`)
3. 直方图均衡化 (`/he_enhanced`)

## QoS设置
所有输出主题使用相同的QoS配置：
- **可靠性**: RELIABLE (保证消息传递)
- **持久性**: VOLATILE (不持久化)
- **历史**: KEEP_LAST (保留最后1条消息)
- **深度**: 1

## 运行步骤

### 1. 安装依赖
```bash
# ROS 2 CV Bridge
sudo apt install ros-humble-cv-bridge

# Python依赖
pip install numpy opencv-python